# AGOMS — Design Notes

## Flight lifecycle (route-aware state diagram)

A flight record represents one airport movement. Therefore an **arrival into
Chennai (CHE)** and a **departure from Chennai** use different operational
paths. The system never treats an arriving flight as if it were immediately
boarding passengers for departure. If an aircraft later operates another
flight out of Chennai, that should be represented by a separate departure
flight record.

### Arrival into Chennai

```
Scheduled
    |
    v
Approaching
    |\
    | \--> EmergencyLanding --> GroundOperations --> Completed
    v
 Arrived
    |
    v
GroundOperations
    |
    v
Completed
```

### Departure from Chennai

```
Scheduled
    |
    v
GroundOperations
    |
    v
Boarding
    |
    v
ReadyForDeparture
    |
    v
Departed
    |
    v
Completed
```

Cancellation is available from eligible pre-completion states. Delays may
pause an eligible state and resume only into a route-appropriate state.

Legal route-aware transitions are implemented by
`Flight::isTransitionAllowed(from, to, origin, destination)` in
`src/models/Flight.cpp`. In particular:

| Flight type | Allowed normal path |
|---|---|
| Arrival (`BOM -> CHE`, for example) | `SCHEDULED -> APPROACHING -> ARRIVED -> GROUND_OPERATIONS -> COMPLETED` |
| Departure (`CHE -> BLR`, for example) | `SCHEDULED -> GROUND_OPERATIONS -> BOARDING -> READY_FOR_DEPARTURE -> DEPARTED -> COMPLETED` |

An arrival flight **cannot** transition from `GROUND_OPERATIONS` to
`BOARDING`, `READY_FOR_DEPARTURE`, or `DEPARTED`. A departure flight **cannot**
transition through `APPROACHING` or `ARRIVED`. This prevents an operationally
incorrect "arrived -> passenger boarding -> departure" cycle on a single
flight record.

Any transition not permitted for the flight's route throws
`InvalidStateTransitionException`, which `ConsoleUI` catches and reports as a
friendly error. The console also displays only route-appropriate target states.

## Resource allocation workflow

```
Operations Manager
        |
        v
ConsoleUI (handleAllocateResources)
        |
        v
AllocationService::allocate(AllocationRequest)
        |
        v
  1. Look up the flight in AirportDatabase; validate it exists.
  2. Validate the flight's current status permits new allocations
     (SCHEDULED / APPROACHING / ARRIVED / EMERGENCY_LANDING /
      GROUND_OPERATIONS / DELAYED).
  3-6. ConflictDetector::checkConflict(request):
       - validates gate/vehicle/staff IDs exist
       - checks each resource isn't in MAINTENANCE
       - checks each resource has no overlapping active allocation
         for the requested time window (queried from AirportDatabase)
        |
        v
  7. If ConflictResult.hasConflict() == false:
       - mark gate/vehicle/staff OCCUPIED in AirportDatabase
       - persist a new Allocation record
       - return AllocationResult::success(allocationId)
     else:
       - mutate nothing
       - return AllocationResult::failure(conflictResult)
```

`AllocationService::release(allocationId)` reverses step 7: it sets the
gate/vehicle/staff back to `AVAILABLE` and marks the `Allocation` as
`RELEASED`. This is exposed in the console UI under
**"4. Allocate Resources" -> "2. Release allocation"**.

## Conflict detection

`ConflictDetector::checkConflict()` (in `services/ConflictDetector.cpp`)
returns a `ConflictResult` with:

- `hasConflict()` — `true`/`false`
- `getConflictType()` — one of `NONE`, `GATE_UNAVAILABLE`,
  `VEHICLE_UNAVAILABLE`, `GROUND_STAFF_UNAVAILABLE`, `TIME_OVERLAP` (folded
  into the specific resource type above, since an overlap is always
  reported against the resource it overlaps on), `INVALID_FLIGHT_STATE`,
  `INVALID_RESOURCE`
- `getDetails()` — a human-readable explanation, e.g.
  `"Gate G01 is already allocated to FL001 for 2026-08-26 09:00 - 2026-08-26 10:30."`

Two time windows `[aStart, aEnd)` and `[bStart, bEnd)` are considered
overlapping via `util::timeWindowsOverlap`, i.e. `aStart < bEnd && bStart <
aEnd`.

## Resource status lifecycle

Every `Resource` subclass (`Gate`, `Vehicle`, `GroundStaffResource`) carries
a `ResourceStatus`: `AVAILABLE`, `OCCUPIED`, `MAINTENANCE`.

- `AllocationService::allocate()` is the only code path that flips
  `AVAILABLE -> OCCUPIED` as a *side effect* of a successful allocation.
- `AllocationService::release()` is the only code path that flips
  `OCCUPIED -> AVAILABLE` as a side effect of a release.
- An administrator can independently set a resource to `MAINTENANCE` (or
  back) via `ResourceService`, which `ConflictDetector` then honors as an
  unconditional unavailability regardless of the time window requested.

## Delay handling workflow

Implemented in `services/DelayService.cpp`, matching the specification
step-by-step:

1. Record delay reason + duration (`FlightDelay` persisted).
2. Flight status -> `DELAYED`.
3. `FlightSchedule` estimated arrival/departure shifted forward by the
   delay duration.
4. Every currently `SUCCESS` allocation for the flight is automatically
   extended at its existing start time by the delay duration.
5. The extension is checked with `ConflictDetector` before it is committed.
6. If the extension conflicts with another flight, `AllocationService`
   automatically searches for a compatible gate, vehicle and ground-staff
   combination for the extended window and updates the same allocation
   record atomically. If no alternative exists, the UI reports the conflict
   for manager intervention.
7. `ConsoleUI` displays the updated schedule and the automatic resource
   handling result immediately after the call returns.

## Emergency landing workflow

Implemented in `services/EmergencyService.cpp`:

1. `declareEmergency(flightId, reason)`: transitions the flight
   `APPROACHING -> EMERGENCY_LANDING` and persists an `EmergencyLanding`
   record with status `DECLARED`.
2. `recordLanding(emergencyId)`: records the landing timestamp, status ->
   `LANDED`.
3. `beginGroundHandling(flightId, emergencyId)`: transitions the flight
   `EMERGENCY_LANDING -> GROUND_OPERATIONS`, emergency status ->
   `GROUND_HANDLING`.
4. `resolveEmergency(emergencyId)`: emergency status -> `RESOLVED`
   (informational close-out; the flight itself continues through its
   normal ground-operations lifecycle from here).

## ATC & Weather integration

`ATCService` is a **simulated** integration per the specification ("this is
an academic simulation... do not require an actual external API") — it
deterministically derives a plausible `ATCClearance` / departure / arrival
description from the flight's *current* `FlightStatus`, and logs it to the
`atc_log` table.

`WeatherService` uses the live Open-Meteo current-weather API for the
configured airport coordinates and logs every successful observation in
SQLite. The API request asks for `timezone=auto`, so the observation timestamp
is interpreted in the airport's local time.

- `getCurrentWeather()` defaults to `CHE` (Chennai Airport).
- `getCurrentWeatherForAirport(code)` supports `CHE`, `BOM`, `BLR`, `DEL`,
  `HYD`, `COK`, `CCU`, `GOI`, `DXB`, and `SIN`.
- `feedWeatherReading(data)` records deterministic manual readings and
  associates each reading with its airport code.
- `getLatestWeatherForAirport(code)` returns the latest observation for that
  specific airport; weather from one airport is never substituted for another.
- `checkWeatherAlert()` derives `NONE`, `ADVISORY`, `WARNING`, or `SEVERE`
  from wind, visibility, precipitation, and WMO condition code thresholds.

### Departure clearance gate

A route must involve `CHE`, but the weather clearance is evaluated at both
the source and destination independently. A flight cannot enter
`READY_FOR_DEPARTURE` or `DEPARTED` unless:

1. Both source and destination have a weather observation no more than
   30 minutes old.
2. Neither endpoint has a `WARNING` or `SEVERE` alert.
3. At least one successful active resource allocation exists.
4. At least one ground-operation task exists and every task is `COMPLETED`.
5. Simulated ATC clearance is `GRANTED`.

Illegal lifecycle transitions are validated before these departure
prerequisites, so an invalid state transition reports the correct exception.

Both services expose the exact method names requested in the specification
(`getFlightStatus`, `getATCClearance`, `getDepartureStatus`,
`getCurrentWeather`, `checkWeatherAlert`), so a real integration could
replace the internals of either without changing any caller.

`FlightMonitor` composes `ATCService` + `WeatherService` + `FlightService`
to produce a `MonitoringSnapshot` (flight status, ATC status, weather,
weather alert, and a list of detected operational issues) — this is what
powers console menu option **6. View Flight Status**.


## Automated Resource Allocation

The Operations Manager can choose **Automatic allocation** instead of entering resource IDs manually. `AllocationService::allocateAutomatically()` reads the flight's estimated schedule and calculates a ground-service window:

- Arrival into CHE (`destination == CHE`): estimated arrival through arrival + 120 minutes.
- Departure from CHE (`origin == CHE`): departure - 120 minutes through estimated departure.

The service then searches gates, vehicles and ground-staff resources, skips resources in `MAINTENANCE`, checks each candidate combination with `ConflictDetector`, and commits the first conflict-free combination using the same atomic allocation workflow as manual allocation. Two ground-staff resources are selected automatically.

This keeps resource selection in the service layer rather than the UI and preserves the existing conflict rules.

#include <gtest/gtest.h>
#include <cstdio>
#include "repositories/AirportDatabase.h"
#include "services/UserService.h"
#include "services/FlightService.h"
#include "services/WeatherService.h"
#include "services/AllocationService.h"
#include "services/GroundOperationsService.h"
#include "services/ReportService.h"
#include "utils/Exceptions.h"
#include "test_time_helpers.h"

using namespace agoms; using namespace agoms::services;

TEST(System, CompleteChennaiDepartureOperationalScenarioPersistsAcrossReopen) {
    const std::string path="system_test_agoms.db"; std::remove(path.c_str());
    {
        repo::AirportDatabase d(path); d.initializeSchema(); UserService us(d); FlightService fs(d); WeatherService ws(d);
        AllocationService as(d); GroundOperationsService gs(d); ReportService rs(d);
        us.createOperationsManagerAccount("sysops","sys-pass-1","System Ops");
        const auto sysStart = agoms_test::futureTime(120);
        fs.createFlight("SYS01","SYS001","CHE","BOM","A320",sysStart,sysStart.addMinutes(60));
        Gate gate("SG1","System Gate"); d.saveGate(gate); Vehicle vehicle("SV1","System Vehicle"); d.saveVehicle(vehicle);
        GroundStaffResource staff("SS1","Ramp"); d.saveGroundStaffResource(staff);
        WeatherData w; w.airportCode="CHE"; w.temperatureCelsius=28; w.windSpeedKmh=10; w.visibilityKm=10; w.precipitationMm=0; w.condition=WeatherCondition::CLEAR; w.observedAt=util::DateTime::now(); ws.feedWeatherReading(w);
        WeatherData dest=w; dest.airportCode="BOM"; ws.feedWeatherReading(dest);
        fs.transitionFlightStatus("SYS01",FlightStatus::GROUND_OPERATIONS);
        AllocationRequest r; r.flightId="SYS01"; r.gateId="SG1"; r.vehicleId="SV1"; r.groundStaffIds={"SS1"}; r.windowStart=sysStart.addMinutes(-30); r.windowEnd=sysStart.addMinutes(90);
        ASSERT_TRUE(as.allocate(r).isSuccess());
        auto task=gs.createTask("SYS01", TaskType::BAGGAGE_HANDLING, "SS1", sysStart.addMinutes(-30), sysStart.addMinutes(30));
        gs.updateTaskStatus(task.getTaskId(), TaskStatus::IN_PROGRESS, "SS1");
        gs.updateTaskStatus(task.getTaskId(), TaskStatus::COMPLETED, "SS1");
        auto report=rs.generateFlightStatusReport(); ASSERT_FALSE(report.getReportId().empty()); ASSERT_FALSE(rs.listSavedReports().empty());
        fs.transitionFlightStatus("SYS01",FlightStatus::PREPARATION_COMPLETED); fs.transitionFlightStatus("SYS01",FlightStatus::BOARDING); fs.transitionFlightStatus("SYS01",FlightStatus::READY_FOR_DEPARTURE); fs.transitionFlightStatus("SYS01",FlightStatus::DEPARTED);
    }
    {
        repo::AirportDatabase d(path); d.initializeSchema();
        ASSERT_TRUE(d.findFlightById("SYS01").has_value());
        ASSERT_EQ(FlightStatus::DEPARTED,d.findFlightById("SYS01")->getStatus());
        ASSERT_TRUE(d.getLatestWeather().has_value());
        ASSERT_FALSE(d.listReportSummaries().empty());
    }
    std::remove(path.c_str()); std::remove((path+"-wal").c_str()); std::remove((path+"-shm").c_str());
}

TEST(System, UnsafeDepartureWithoutWeatherIsRejected) {
    repo::AirportDatabase d(":memory:"); d.initializeSchema(); FlightService fs(d);
    fs.createFlight("SYS02","SYS002","CHE","BOM","A320",agoms_test::futureTime(180),agoms_test::futureTime(240));
    fs.transitionFlightStatus("SYS02",FlightStatus::GROUND_OPERATIONS); fs.transitionFlightStatus("SYS02",FlightStatus::PREPARATION_COMPLETED); fs.transitionFlightStatus("SYS02",FlightStatus::BOARDING);
    ASSERT_THROW(fs.transitionFlightStatus("SYS02",FlightStatus::READY_FOR_DEPARTURE),ValidationException);
}

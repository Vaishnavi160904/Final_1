#include <gtest/gtest.h>
#include "repositories/AirportDatabase.h"
#include "services/FlightService.h"
#include "services/AllocationService.h"
#include "services/DelayService.h"
#include "services/EmergencyService.h"
#include "utils/Exceptions.h"
#include "test_time_helpers.h"

using namespace agoms;
using namespace agoms::services;

namespace {
struct DelayFixture {
    repo::AirportDatabase db{":memory:"};
    FlightService flights{db};
    AllocationService allocations{db};
    DelayService delays{db, flights, allocations};

    DelayFixture() {
        db.initializeSchema();
        flights.createFlight("FD01", "AI700", "CHE", "BOM", "A320",
                              agoms_test::futureTime(60),
                              agoms_test::futureTime(150));
        flights.transitionFlightStatus("FD01", FlightStatus::GROUND_OPERATIONS);
    }
};
}

// Test 9: Delay handling
TEST(Delay, ApplyDelayUpdatesStatusAndSchedule) {
    DelayFixture fx;
    DelayOutcome outcome = fx.delays.applyDelay("FD01", DelayReason::WEATHER, 45, "Storm on approach");

    ASSERT_EQ(std::string("FD01"), outcome.delay.getFlightId());
    ASSERT_EQ(45, outcome.delay.getDelayMinutes());
    ASSERT_TRUE(fx.flights.getFlight("FD01").getStatus() == FlightStatus::DELAYED);

    auto schedule = fx.flights.getSchedule("FD01");
    ASSERT_TRUE(schedule.has_value());
    // Estimated arrival should be 45 minutes after the original scheduled arrival.
    long diff = schedule->getEstimatedArrival().minutesSince(schedule->getScheduledArrival());
    ASSERT_EQ(45L, diff);
}

TEST(Delay, NonPositiveDurationRejected) {
    DelayFixture fx;
    ASSERT_THROW(fx.delays.applyDelay("FD01", DelayReason::OTHER, 0, ""), ValidationException);
}

TEST(Delay, RecordedInHistory) {
    DelayFixture fx;
    fx.delays.applyDelay("FD01", DelayReason::ATC, 20, "ATC hold");
    auto history = fx.delays.listDelaysForFlight("FD01");
    ASSERT_EQ(static_cast<size_t>(1), history.size());
    ASSERT_TRUE(history[0].getReason() == DelayReason::ATC);
}

// Test 10: Emergency landing
namespace {
struct EmergencyFixture {
    repo::AirportDatabase db{":memory:"};
    FlightService flights{db};
    EmergencyService emergencies{db, flights};

    EmergencyFixture() {
        db.initializeSchema();
        flights.createFlight("FE01", "AI800", "BOM", "CHE", "A320",
                              agoms_test::futureTime(60),
                              agoms_test::futureTime(150));
        flights.transitionFlightStatus("FE01", FlightStatus::APPROACHING);
    }
};
}

TEST(Emergency, DeclareTransitionsFlightAndRecordsDetails) {
    EmergencyFixture fx;
    EmergencyLanding emergency = fx.emergencies.declareEmergency("FE01", "Engine failure");

    ASSERT_TRUE(fx.flights.getFlight("FE01").getStatus() == FlightStatus::EMERGENCY_LANDING);
    ASSERT_EQ(std::string("FE01"), emergency.getFlightId());
    ASSERT_TRUE(emergency.getStatus() == EmergencyStatus::DECLARED);
}

TEST(Emergency, FullWorkflowReachesGroundHandling) {
    EmergencyFixture fx;
    EmergencyLanding emergency = fx.emergencies.declareEmergency("FE01", "Hydraulic failure");

    EmergencyLanding landed = fx.emergencies.recordLanding(emergency.getEmergencyId());
    ASSERT_TRUE(landed.getStatus() == EmergencyStatus::LANDED);

    fx.emergencies.beginGroundHandling("FE01", emergency.getEmergencyId());
    ASSERT_TRUE(fx.flights.getFlight("FE01").getStatus() == FlightStatus::GROUND_OPERATIONS);

    fx.emergencies.resolveEmergency(emergency.getEmergencyId());
    EmergencyLanding resolved = fx.emergencies.getEmergency(emergency.getEmergencyId());
    ASSERT_TRUE(resolved.getStatus() == EmergencyStatus::RESOLVED);
}

TEST(Emergency, CannotDeclareFromScheduledState) {
    repo::AirportDatabase db(":memory:");
    db.initializeSchema();
    FlightService flights(db);
    EmergencyService emergencies(db, flights);
    flights.createFlight("FE02", "AI801", "CHE", "BOM", "A320",
                          agoms_test::futureTime(60),
                          agoms_test::futureTime(150));
    // Flight is still SCHEDULED (never transitioned to APPROACHING).
    ASSERT_THROW(emergencies.declareEmergency("FE02", "Bird strike"), InvalidStateTransitionException);
}

TEST(Delay, AutomaticallyExtendsExistingAllocation) {
    DelayFixture fx;
    ResourceService resources(fx.db);
    resources.addGate("DG01", "A");
    resources.addVehicle("DV01", "Baggage Tractor");
    resources.addGroundStaffResource("DS01", "Ramp");
    resources.addGroundStaffResource("DS02", "Baggage");

    const auto start = agoms_test::futureTime(240);
    const auto end = agoms_test::futureTime(300);
    AllocationRequest request;
    request.flightId = "FD01";
    request.gateId = "DG01";
    request.vehicleId = "DV01";
    request.groundStaffIds = {"DS01", "DS02"};
    request.windowStart = start;
    request.windowEnd = end;
    auto result = fx.allocations.allocate(request);
    ASSERT_TRUE(result.isSuccess());

    fx.delays.applyDelay("FD01", DelayReason::WEATHER, 30, "Weather delay");
    auto allocs = fx.allocations.listAllocationsForFlight("FD01");
    ASSERT_EQ(1u, allocs.size());
    ASSERT_EQ(start, allocs[0].getWindowStart());
    ASSERT_EQ(end.addMinutes(30), allocs[0].getWindowEnd());
}

TEST(Delay, AutomaticallyReallocatesWhenExtensionConflicts) {
    DelayFixture fx;
    ResourceService resources(fx.db);
    resources.addGate("DG01", "A");
    resources.addGate("DG02", "B");
    resources.addVehicle("DV01", "Baggage Tractor");
    resources.addVehicle("DV02", "Pushback Tug");
    resources.addGroundStaffResource("DS01", "Ramp");
    resources.addGroundStaffResource("DS02", "Baggage");
    resources.addGroundStaffResource("DS03", "Fuel");
    resources.addGroundStaffResource("DS04", "Catering");
    fx.flights.createFlight("FD02", "AI701", "CHE", "BOM", "A320",
                            agoms_test::futureTime(360), agoms_test::futureTime(450));

    const auto start = agoms_test::futureTime(240);
    const auto end = agoms_test::futureTime(300);
    AllocationRequest first{"FD01", "DG01", "DV01", {"DS01", "DS02"}, start, end};
    ASSERT_TRUE(fx.allocations.allocate(first).isSuccess());

    AllocationRequest blocker{"FD02", "DG01", "DV01", {"DS01", "DS02"}, end, end.addMinutes(60)};
    ASSERT_TRUE(fx.allocations.allocate(blocker).isSuccess());

    auto outcome = fx.delays.applyDelay("FD01", DelayReason::WEATHER, 30, "Weather delay");
    ASSERT_EQ(1u, outcome.resourceWarnings.size());
    auto allocs = fx.allocations.listAllocationsForFlight("FD01");
    ASSERT_EQ(1u, allocs.size());
    ASSERT_NE("DG01", allocs[0].getGateId());
    ASSERT_NE("DV01", allocs[0].getVehicleId());
    ASSERT_EQ(start, allocs[0].getWindowStart());
    ASSERT_EQ(end.addMinutes(30), allocs[0].getWindowEnd());
}

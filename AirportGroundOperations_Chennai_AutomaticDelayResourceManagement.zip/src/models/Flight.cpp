#include "models/Flight.h"
#include "utils/Exceptions.h"
#include <vector>
#include <utility>

namespace agoms {

Flight::Flight(std::string flightId, std::string flightNumber, std::string origin,
               std::string destination, std::string aircraftType)
    : flightId_(std::move(flightId)),
      flightNumber_(std::move(flightNumber)),
      origin_(std::move(origin)),
      destination_(std::move(destination)),
      aircraftType_(std::move(aircraftType)),
      status_(FlightStatus::SCHEDULED) {}

bool Flight::isTransitionAllowed(FlightStatus from, FlightStatus to) {
    using FS = FlightStatus;
    // Generic state graph retained for model-level compatibility. The
    // service layer uses the route-aware overload below so an arrival flight
    // can never be treated as a departure flight.
    static const std::vector<std::pair<FS, FS>> allowed = {
        {FS::SCHEDULED, FS::APPROACHING},
        {FS::SCHEDULED, FS::GROUND_OPERATIONS},
        {FS::SCHEDULED, FS::DELAYED},
        {FS::SCHEDULED, FS::CANCELLED},
        {FS::APPROACHING, FS::ARRIVED},
        {FS::APPROACHING, FS::EMERGENCY_LANDING},
        {FS::APPROACHING, FS::CANCELLED},
        {FS::EMERGENCY_LANDING, FS::GROUND_OPERATIONS},
        {FS::ARRIVED, FS::GROUND_OPERATIONS},
        {FS::GROUND_OPERATIONS, FS::PREPARATION_COMPLETED},
        {FS::PREPARATION_COMPLETED, FS::BOARDING},
        {FS::PREPARATION_COMPLETED, FS::COMPLETED},
        {FS::GROUND_OPERATIONS, FS::DELAYED},
        {FS::BOARDING, FS::READY_FOR_DEPARTURE},
        {FS::BOARDING, FS::DELAYED},
        {FS::READY_FOR_DEPARTURE, FS::DEPARTED},
        {FS::READY_FOR_DEPARTURE, FS::DELAYED},
        {FS::DEPARTED, FS::COMPLETED},
        {FS::DELAYED, FS::APPROACHING},
        {FS::DELAYED, FS::GROUND_OPERATIONS},
        {FS::DELAYED, FS::BOARDING},
        {FS::DELAYED, FS::READY_FOR_DEPARTURE},
        {FS::DELAYED, FS::CANCELLED},
    };
    if (from == to) return false;
    for (const auto& edge : allowed) {
        if (edge.first == from && edge.second == to) return true;
    }
    return false;
}

bool Flight::isTransitionAllowed(FlightStatus from, FlightStatus to,
                                 const std::string& origin,
                                 const std::string& destination) {
    using FS = FlightStatus;
    if (from == to) return false;

    const bool isDeparture = origin == "CHE" && destination != "CHE";
    const bool isArrival = destination == "CHE" && origin != "CHE";
    if (!isDeparture && !isArrival) return false;

    static const std::vector<std::pair<FS, FS>> common = {
        {FS::SCHEDULED, FS::DELAYED},
        {FS::SCHEDULED, FS::CANCELLED},
        {FS::GROUND_OPERATIONS, FS::DELAYED},
        {FS::DELAYED, FS::CANCELLED},
    };
    for (const auto& edge : common) {
        if (edge.first == from && edge.second == to) return true;
    }

    if (isArrival) {
        static const std::vector<std::pair<FS, FS>> arrival = {
            {FS::SCHEDULED, FS::APPROACHING},
            {FS::APPROACHING, FS::ARRIVED},
            {FS::APPROACHING, FS::EMERGENCY_LANDING},
            {FS::APPROACHING, FS::CANCELLED},
            {FS::EMERGENCY_LANDING, FS::GROUND_OPERATIONS},
            {FS::ARRIVED, FS::GROUND_OPERATIONS},
            {FS::GROUND_OPERATIONS, FS::PREPARATION_COMPLETED},
            {FS::PREPARATION_COMPLETED, FS::COMPLETED},
            {FS::DELAYED, FS::APPROACHING},
            {FS::DELAYED, FS::ARRIVED},
            {FS::DELAYED, FS::GROUND_OPERATIONS},
        };
        for (const auto& edge : arrival) {
            if (edge.first == from && edge.second == to) return true;
        }
    }

    if (isDeparture) {
        static const std::vector<std::pair<FS, FS>> departure = {
            {FS::SCHEDULED, FS::GROUND_OPERATIONS},
            {FS::GROUND_OPERATIONS, FS::PREPARATION_COMPLETED},
            {FS::PREPARATION_COMPLETED, FS::BOARDING},
            {FS::BOARDING, FS::READY_FOR_DEPARTURE},
            {FS::READY_FOR_DEPARTURE, FS::DEPARTED},
            {FS::DEPARTED, FS::COMPLETED},
            {FS::DELAYED, FS::GROUND_OPERATIONS},
            {FS::DELAYED, FS::BOARDING},
            {FS::DELAYED, FS::READY_FOR_DEPARTURE},
        };
        for (const auto& edge : departure) {
            if (edge.first == from && edge.second == to) return true;
        }
    }
    return false;
}

void Flight::transitionTo(FlightStatus newStatus) {
    if (!isTransitionAllowed(status_, newStatus, origin_, destination_)) {
        throw InvalidStateTransitionException(
            "Illegal flight state transition for " + flightId_ + ": " +
            toString(status_) + " -> " + toString(newStatus));
    }
    status_ = newStatus;
}

} // namespace agoms

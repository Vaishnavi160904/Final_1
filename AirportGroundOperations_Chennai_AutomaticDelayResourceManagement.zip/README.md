# Airport Ground Operations Management System (AGOMS)

## Live weather API and TXT reports

The Weather menu fetches **live current conditions** from the Open-Meteo Forecast API (no API key required). Weather values are not hard-coded: temperature, wind speed, visibility, precipitation, weather code, and observation time come from the API response and are persisted to `weather_log`. The application is Chennai-Airport focused for flight routing (`CHE` must be one endpoint), but weather can be fetched independently for `CHE`, `BOM`, `BLR`, `DEL`, `HYD`, `COK`, `CCU`, `GOI`, `DXB`, and `SIN` so both source and destination weather clearance can be evaluated. Airport coordinates are static configuration values used only to tell Open-Meteo which location to query. Open-Meteo documents the current-weather endpoint and variables here: https://open-meteo.com/en/docs.

On Linux/WSL, install the HTTP development package before configuring CMake:

```bash
sudo apt update
sudo apt install -y cmake g++ make libcurl4-openssl-dev
```

The Reports menu can save each generated report as a `.txt` file under the `reports/` directory. Option 8 saves all six report types at once.

Example:

```text
12. Generate Reports
8. Generate all reports as TXT files
```



A C++17 console application for managing airport ground resources and
flight operations: flights, gates, vehicles, ground staff, resource
allocation with conflict detection, ground operations, flight delays,
emergency landings, and simulated ATC integration and live Open-Meteo weather integration — backed by a
real SQLite persistence layer.

## 1. Project Overview

AGOMS lets an **Operations Manager** allocate gates, vehicles and ground
staff to flights while automatically detecting and rejecting conflicting
allocations; track flights through a well-defined lifecycle state machine;
handle delays and emergency landings; and generate operational reports. An
**Airport Administrator** manages the underlying master data (flights,
gates, vehicles, ground staff, user accounts). **Ground Staff** log in to
see their assigned tasks and update task status. The system also exposes
simulated **ATC** and **Weather** integrations that feed into flight
monitoring, delay handling and emergency response.

## 2. Objective

Build a layered, testable, UML-faithful C++ system that demonstrates:
resource-conflict-safe allocation, a proper flight-state lifecycle, clean
separation of presentation / business logic / domain / persistence, and a
real (not mocked) relational persistence layer, entirely from the console.

## 3. Scope

In scope: flight & resource master data management, allocation with
conflict detection, ground task tracking, delay handling, emergency
landing handling, simulated ATC integration and live Open-Meteo weather integration, reporting, and a
console UI. Out of scope (explicitly, per the assignment brief): a GUI,
a real external ATC API, and multithreaded background schedulers
(the system is fully synchronous and correct without threads; see
`docs/architecture.md` §Threading for how background polling could be
layered on top later without touching business logic).

## 4. Features

- Role-based accounts: Airport Administrator, Operations Manager, Ground Staff
- Flight master data + an 11-state lifecycle state machine with a validated
  transition table (route-aware paths: arrival flights use `Scheduled → Approaching → Arrived →
  GroundOperations → Completed`; departure flights use `Scheduled →
  GroundOperations → Boarding → ReadyForDeparture → Departed → Completed`, plus
  `EmergencyLanding`, `Delayed`, `Cancelled` side-paths)
- Gate / Vehicle / GroundStaffResource master data with
  `AVAILABLE / OCCUPIED / MAINTENANCE` status
- Resource allocation with full conflict detection (gate/vehicle/staff
  availability + time-window overlap) before any resource is committed
- Resource release (returns resources to `AVAILABLE`)
- Ground task management (baggage handling, cleaning, fueling, catering,
  boarding support) with `PENDING/ASSIGNED/IN_PROGRESS/COMPLETED/DELAYED`
  status, updatable by Ground Staff
- Flight delay handling: records reason & duration, updates flight status
  and schedule, and re-validates previously allocated resources against the
  new time window
- Emergency landing handling: declare → record landing → begin ground
  handling → resolve
- Simulated ATC integration (`getFlightStatus`, `getATCClearance`,
  `getDepartureStatus`)
- Live Open-Meteo Weather integration (`getCurrentWeather`, `getCurrentWeatherForAirport`, `checkWeatherAlert`)
- Flight monitoring that composes ATC + Weather + Flight state into one
  operational snapshot
- Six report types: flight status, resource utilization, allocation, delay,
  emergency, ground operation — generated and persisted for later recall
- Real SQLite persistence (not an in-memory-only mock)
- regression and unit tests covering flight/resource creation, successful allocation,
  gate/vehicle/staff conflicts, release, state transitions, delay,
  emergency landing, and database persistence-across-reopen

## 5. Architecture

```
Presentation Layer   -> controllers/ConsoleUI
Service Layer        -> services/* (FlightService, ResourceService,
                         AllocationService, ConflictDetector, ATCService,
                         WeatherService, FlightMonitor, DelayService,
                         EmergencyService, GroundOperationsService,
                         ReportService, UserService)
Domain Model Layer    -> models/* (Flight, Resource, Allocation, GroundTask,
                         FlightDelay, EmergencyLanding, WeatherData,
                         ATCStatus, Report, User hierarchy, ...)
Repository Layer      -> repositories/AirportDatabase (SQLite-backed)
```

Full details, the design-pattern rationale, and a discussion of the
project's SQLite linking approach are in **`docs/architecture.md`**.
Complete workflow walkthroughs (allocation, conflict detection, delay,
emergency landing, flight lifecycle) are in **`docs/design.md`**.

## 6. Module ↔ Class Map

| Module (spec §3) | Key classes |
|---|---|
| A. User Management | `User`, `AirportAdministrator`, `OperationsManager`, `GroundStaff`, `UserService` |
| B. Flight Management | `Flight`, `FlightSchedule`, `FlightService` |
| C. Resource Management | `Resource`, `Gate`, `Vehicle`, `GroundStaffResource`, `ResourceService` |
| D. Allocation Management | `Allocation`, `AllocationRequest`, `AllocationResult`, `AllocationService` |
| E. Conflict Detection | `ConflictDetector`, `ConflictResult` |
| F. Ground Operations Management | `GroundTask`, `GroundOperationsService` |
| G. Flight Monitoring | `FlightMonitor`, `MonitoringSnapshot` |
| H. Delay Management | `FlightDelay`, `DelayService`, `DelayOutcome` |
| I. Emergency Landing Management | `EmergencyLanding`, `EmergencyService` |
| J. ATC Integration | `ATCStatus`, `ATCService` |
| K. Weather Integration | `WeatherData`, `WeatherAlert`, `WeatherService` |
| L. Reporting | `Report`, `ReportService` |
| M. Database/Persistence | `AirportDatabase` |

**Note on `GroundStaff` vs `GroundStaffResource`:** the specification lists
`GroundStaff` both as a `User` subclass (an actor who logs in) and
implicitly as an allocatable resource. This implementation keeps those as
two distinct classes — `models/GroundStaff.h` (a login identity, subclass
of `User`) and `models/GroundStaffResource.h` (an allocatable crew
resource, subclass of `Resource`) — linked via
`GroundStaff::getLinkedResourceId()`. This avoids conflating "who can log
in" with "what can be scheduled," which would otherwise force `User` to
carry `ResourceStatus` and allocation-window fields that make no sense for
an Administrator or Operations Manager account.

## 7. Database Design

SQLite, accessed through `repositories/AirportDatabase`. Full DDL is in
[`database/schema.sql`](database/schema.sql) (also executed
programmatically at startup via `AirportDatabase::initializeSchema()`, so
the file and the code are guaranteed to match). Key tables:

`users`, `flights`, `flight_schedules`, `gates`, `vehicles`,
`ground_staff_resources`, `allocations` (+ `allocation_staff` junction
table for the many ground-staff-per-allocation relationship),
`ground_tasks`, `flight_delays`, `emergency_landings`, `weather_log`,
`atc_log`, `reports`.

All queries are parameterized (`sqlite3_bind_*`) — no string-concatenated
SQL anywhere in the codebase.

**Why a hand-written `sqlite3_min.h` instead of `#include <sqlite3.h>`?**
See `docs/architecture.md` — in short: this project links against the real
system `libsqlite3` shared library, but declares the small subset of the
C API it needs by hand in `third_party/sqlite3/sqlite3_min.h`, so that it
still builds in environments that have the SQLite runtime but not the
`libsqlite3-dev` header package. If your machine has `libsqlite3-dev`
installed, the build works identically either way.

## 8. Build Instructions

**Requirements:** a C++17 compiler (g++ 9+ / clang 10+), CMake 3.16+, and
the SQLite3 runtime library (`libsqlite3-0` or equivalent — present on
almost all Linux systems by default; install `libsqlite3-dev` too if you'd
rather use the official `sqlite3.h`, which also works unmodified).

```bash
cmake -S . -B build
cmake --build build -j4
```

This produces:
- `build/agoms_app` — the main console application
- `build/agoms_tests` — the unit test suite

If CMake reports it cannot find `libsqlite3` on an unusual system, install
the runtime library, e.g. on Debian/Ubuntu:
```bash
sudo apt-get install libsqlite3-0        # runtime only, sufficient to build this project
# or
sudo apt-get install libsqlite3-dev      # official headers, also works
```

**Manual build (no CMake required)** — every source file compiles cleanly
with a single g++ invocation, which is how this project was verified in an
offline sandbox with no CMake available:
```bash
g++ -std=c++17 -Iinclude -Ithird_party/sqlite3 \
    $(find src -name '*.cpp') main.cpp \
    -o agoms_app -lsqlite3
```
(If `-lsqlite3` isn't found because only the runtime `.so.0` exists without
a `.so` symlink, link the file directly, e.g.
`/usr/lib/x86_64-linux-gnu/libsqlite3.so.0` — this is exactly what
`CMakeLists.txt` does automatically via its `find_library` fallback.)

## 9. Run Instructions

```bash
./build/agoms_app                # creates/opens ./agoms.db in the current directory
./build/agoms_app custom_path.db # or specify a database file explicitly
```

On first run against a fresh/empty database, the app automatically creates
the schema and seeds sample data (see §12 below). On subsequent runs it
reuses the existing data.

## 10. Test Instructions

```bash
cmake --build build --target agoms_tests
./build/agoms_tests
```

The project uses the real **GoogleTest (GTest)** framework. CMake downloads
GoogleTest 1.17.0 with `FetchContent`, builds the test executable, and registers
it with CTest. The tests use standard GoogleTest APIs such as `TEST()`,
`ASSERT_EQ()`, `ASSERT_TRUE()`, `ASSERT_FALSE()`, `ASSERT_THROW()`, and
`RUN_ALL_TESTS()`.

There are currently **75 GoogleTest test cases** covering flights, resources,
allocation/conflict detection, database persistence/authentication, weather,
delays, and emergency landing.

If the target machine is offline, download GoogleTest 1.17.0 once and make it
available to CMake, or configure/build on a machine with network access so
`FetchContent` can retrieve the pinned release.

## 11. Sample Login Credentials

Seeded automatically on first run:

| Username | Password | Role |
|---|---|---|
| `admin` | `admin123` | Airport Administrator |
| `opsmgr` | `ops123` | Operations Manager |
| `staff1` | `staff123` | Ground Staff (linked to resource `GS01`) |
| `staff2` | `staff123` | Ground Staff (linked to resource `GS02`) |

## 12. Sample Data

Seeded on first run against an empty database (also documented in
[`database/seed.sql`](database/seed.sql)):

- Flights: `FL001` (AI101, CHE→BOM), `FL002` (AI202, BOM→CHE), `FL003`
  (AI303, CHE→BLR), each with a schedule
- Gates: `G01`, `G02` (Terminal A), `G03` (Terminal B) — all `AVAILABLE`
- Vehicles: `V01` (Baggage Tractor), `V02` (Fuel Truck) — all `AVAILABLE`
- Ground staff resources: `GS01`..`GS04` — all `AVAILABLE`

## 13. Sample Workflow & Verified Test Results

### 13.1 Allocation success + conflict detection (the required demo scenario)

Logged in as `opsmgr`, from the Main Menu: **4. Allocate Resources → 1. New
allocation**.

**Request 1** — Flight `FL001`, Gate `G01`, Vehicle `V01`, Staff
`GS01,GS02`, window `2026-08-26 09:00`–`2026-08-26 10:30`:

```
Allocation Succeeded. Allocation ID: AL0001
Gate G01 -> OCCUPIED
Vehicle V01 -> OCCUPIED
Staff GS01 -> OCCUPIED
Staff GS02 -> OCCUPIED
```

**Request 2** — Flight `FL002`, Gate `G01` (same gate, overlapping window
`09:15`–`10:00`):

```
Allocation Failed
Conflict: Gate G01 is already allocated to FL001 for 2026-08-26 09:00 - 2026-08-26 10:30.
```

**Releasing** `AL0001` (Main Menu → 4 → 2 → `AL0001`):

```
Allocation AL0001 released. Gate, vehicle and ground staff are now AVAILABLE again.
```

Listing gates afterward confirms `G01` is `AVAILABLE` again, and a new
flight can now successfully allocate it for the same window.

*(This exact sequence is also covered automatically by
`Allocation_SuccessfulAllocationOccupiesResourcesAndPersistsRecord`,
`Allocation_OverlappingGateRequestFails`, and
`Allocation_ReleaseReturnsResourcesToAvailable` in `tests/test_allocation.cpp`.)*

### 13.2 Full flight lifecycle

Verified end-to-end (Main Menu → 2 → 3, repeated):
`BOM → CHE arrival: SCHEDULED → APPROACHING → ARRIVED → GROUND_OPERATIONS → COMPLETED`

`CHE → destination departure: SCHEDULED → GROUND_OPERATIONS → BOARDING → READY_FOR_DEPARTURE → DEPARTED → COMPLETED`, with each illegal transition attempt (e.g.
`SCHEDULED → DEPARTED`) correctly rejected with a clear error message
rather than crashing.

### 13.3 GoogleTest unit-test suite

The project now uses the real GoogleTest runner. The suite contains **75 test
cases** across five test source files:

| Test file | Coverage |
|---|---|
| `test_flight.cpp` | Flight creation and state transitions |
| `test_resources.cpp` | Gate, vehicle and ground-staff resources |
| `test_allocation.cpp` | Allocation, overlap/conflict detection and release |
| `test_delay_emergency.cpp` | Delays and emergency-landing workflow |
| `test_database.cpp` | Persistence, authentication and weather history |

Run the suite with:

```bash
cmake -S . -B build
cmake --build build -j2
./build/agoms_tests
```

Or through CTest:

```bash
ctest --test-dir build --output-on-failure
```

GoogleTest prints the standard `[ RUN ]`, `[ OK ]`, `[ FAILED ]` summary and
supports filters such as:

```bash
./build/agoms_tests --gtest_filter=Flight*
./build/agoms_tests --gtest_list_tests
```

## 14. Resource Allocation Flow

See `docs/design.md` §"Resource allocation workflow" for the full
step-by-step trace matching spec §8
(`UI → AllocationService → validate flight → ConflictDetector →
AirportDatabase → AllocationResult`).

## 15. Conflict Handling

See `docs/design.md` §"Conflict detection". Summary: `ConflictDetector`
validates flight/resource IDs exist, checks each requested resource isn't
in `MAINTENANCE`, and checks each requested resource has no other
`SUCCESS`-status allocation whose time window overlaps the request. Any one
conflict aborts the whole allocation atomically (no partial allocation is
ever persisted).

## 16. Flight State Lifecycle

See §4 above and `docs/design.md` §"Flight lifecycle" for the full
transition table and rationale.

## 17. ATC Integration

`ATCService` (simulated) exposes `getFlightStatus`, `getATCClearance`,
`getDepartureStatus`, `getArrivalStatus`. Every call is also logged to the
`atc_log` table. See `docs/design.md` §"ATC & Weather integration".

## 18. Weather Integration

`WeatherService::getCurrentWeather()` polls the **live** Open-Meteo weather
API: every call generates a new live Open-Meteo reading and immediately
logs it to the `weather_log` table — so checking the weather repeatedly
gives different, realistic values each time (nothing is cached or frozen),
while the database still accumulates a permanent history of every reading
ever taken. `feedWeatherReading()` (console: **View Weather → 2**) lets
an operator inject one specific, exact reading instead — handy for
demonstrating how a forced `STORM`/`SEVERE` reading affects delay and
emergency handling. `checkWeatherAlert()` derives `NONE`/`ADVISORY`/
`WARNING`/`SEVERE` from wind/visibility/precipitation/condition
thresholds. See `docs/design.md`.

## 19. Future Enhancements

- Automatic reallocation suggestions (rather than warnings only) when a
  delay invalidates a previously allocated resource
- A background monitoring thread that periodically calls
  `FlightMonitor::monitor()` for all in-flight/ground-active flights and
  proactively raises alerts, rather than requiring a manual menu check
  (the architecture already supports this without any service-layer
  changes — see `docs/architecture.md` §Threading)
- Password hashing upgraded from the current demo-grade hash to
  bcrypt/argon2 with per-user salt for any real deployment
- A real external ATC API integration behind the existing
  `ATCService`/`WeatherService` interfaces
- A web or GUI front-end reusing the existing service layer unchanged

## 20. Project Structure

```
AirportGroundOperations/
├── CMakeLists.txt
├── README.md
├── LICENSE
├── main.cpp
├── include/
│   ├── models/         (Enums, User hierarchy, Flight, Resource hierarchy,
│   │                     Allocation*, GroundTask, FlightDelay,
│   │                     EmergencyLanding, WeatherData/Alert, ATCStatus,
│   │                     Report, ConflictResult)
│   ├── services/        (UserService, FlightService, ResourceService,
│   │                     ConflictDetector, AllocationService, ATCService,
│   │                     WeatherService, FlightMonitor, DelayService,
│   │                     EmergencyService, GroundOperationsService,
│   │                     ReportService)
│   ├── repositories/     (AirportDatabase)
│   ├── controllers/      (ConsoleUI)
│   └── utils/            (DateTime, Exceptions)
├── src/                 (mirrors include/, plus the .cpp implementations)
├── third_party/sqlite3/  (sqlite3_min.h — see docs/architecture.md)
├── database/
│   ├── schema.sql
│   └── seed.sql
├── tests/
│   ├── test_main.cpp
│   ├── test_flight.cpp
│   ├── test_resources.cpp
│   ├── test_allocation.cpp
│   ├── test_delay_emergency.cpp
│   └── test_database.cpp
└── docs/
    ├── architecture.md
    └── design.md
```


## Validation and GTest regression coverage

The corrected version adds business-rule validation for allocation/task windows,
flight creation, emergency workflow transitions, ground-staff authorization,
resource release consistency, duplicate allocations, and multiple delays.

GoogleTest is the real GTest framework. The suite contains the 71 tests
plus regression tests covering the corrected edge cases. Build and run with:

```bash
rm -rf build
cmake -S . -B build
cmake --build build -j2
./build/agoms_tests
# or
ctest --test-dir build --output-on-failure
```

The first configure downloads GoogleTest 1.17.0 if it is not already cached.
For offline environments, make the GoogleTest source available to CMake's
FetchContent cache before configuring.

## User interface and roles

The application starts with a small unauthenticated menu:

1. Login
2. Exit

After login, the main menu is selected from the authenticated user's role:

- **Administrator:** Create User, Flight Management, Resource Management, Weather, ATC, Reports, Logout.
- **Operations Manager:** Flight Operations, Resource Allocation, Conflict Checks, Ground Tasks, Delays, Emergency Handling, Weather, ATC, Reports, Logout.
- **Ground Staff:** My Ground Tasks, Flight Status, Weather, ATC, Reports, Logout.

Only the Administrator can create new Operations Manager and Ground Staff accounts. Public sign-up is not available.

## Test database initialization

`AirportDatabase` creates its idempotent schema in its constructor. This makes service constructors safe in unit-test fixtures even when the fixture calls `initializeSchema()` later. Calling `initializeSchema()` explicitly remains supported and harmless.


## Chennai Airport scope

This application is configured for the Chennai Airport project location. Live weather uses the Open-Meteo API for **CHE, BOM, BLR, DEL, HYD, COK, CCU, GOI, DXB, and SIN**. Flight creation still requires Chennai (`CHE`) to be one endpoint; non-Chennai-to-non-Chennai routes are rejected. 

The weather parser reads values from Open-Meteo's `current` object rather than `current_units`, preventing unit strings such as `"temperature_2m": "°C"` from being mistaken for numeric weather values.

## Testing coverage
The GoogleTest suite is organized into four testing levels:
- Unit testing: individual models/services/repository behaviors (`test_flight.cpp`, `test_resources.cpp`, `test_allocation.cpp`, `test_delay_emergency.cpp`, `test_database.cpp`, `test_regressions.cpp`).
- Integration testing: real Flight, Weather, Allocation, Delay and Emergency services working together (`test_integration.cpp`).
- Functional testing: complete user/business actions such as authentication, Chennai-only routing and weather-gated departure (`test_functional.cpp`).
- System testing: end-to-end operational scenario including SQLite persistence/reopen and departure safety (`test_system.cpp`).
All network-dependent weather tests use deterministic/manual readings or parser tests; live Open-Meteo access is not required for the test suite.

### Running the complete test suite
From the project root run:
```bash
./run_tests.sh
```
The suite contains **68 GoogleTest cases** covering unit, integration, functional, regression and system levels. Tests that exercise weather use deterministic readings/parser inputs, so the test result does not depend on live Internet access.


## Departure clearance rules
A flight may be moved to READY_FOR_DEPARTURE/DEPARTED only after:
1. The route involves CHE (Chennai Airport).
2. Fresh weather (maximum age 30 minutes) exists for both source and destination.
3. Neither endpoint has a WARNING or SEVERE weather alert.
4. At least one successful active resource allocation exists.
5. Ground-operation tasks exist and every task is COMPLETED.
6. Simulated ATC clearance is GRANTED.
For a Chennai-centered route, weather is evaluated independently at both endpoints; Chennai is not substituted for the destination weather.


## 14. Final departure-clearance workflow

For every Chennai-involved flight, the Operations Manager follows:

`Flight -> source weather -> destination weather -> resource allocation -> ground tasks -> ATC -> READY_FOR_DEPARTURE -> DEPARTED`

Weather observations expire after 30 minutes for departure clearance. A
WARNING or SEVERE alert at either endpoint blocks departure. A missing weather
reading, missing active allocation, incomplete ground task, or non-GRANTED ATC
status also blocks departure. This is a planning rule for the academic
simulation, not real-world aviation certification logic.

The current automated suite contains 71 tests across unit, integration,
functional, regression, and system scenarios.


## Automated resource allocation
The Operations Manager can automatically allocate a conflict-free gate, vehicle, and two ground-staff resources from the flight schedule.

### Using automatic allocation
1. Log in as `opsmgr` / `ops123`.
2. Open **2. Allocate Resources**.
3. Choose **1. Automatic allocation (recommended)**.
4. Enter a flight ID such as `FL001`.
5. The application automatically selects a gate, vehicle and two ground-staff resources for the flight's scheduled ground-service window.
6. The selected resource IDs and allocation window are displayed, and the allocation is persisted.

The menu still provides **Manual allocation** when a specific gate, vehicle or staff combination must be demonstrated.

### Sample resource inventory
A fresh database now contains the following 19 resources. The ten rows marked **additional** were added for automatic-allocation demonstrations:

| Type | IDs | Examples |
|---|---|---|
| Gates | G01-G07 | terminals A, B, C, D |
| Vehicles | V01-V05 | baggage tractor, fuel truck, pushback tug, catering truck, water service truck |
| Ground staff | GS01-GS07 | baggage handling, ramp agent, cleaning, catering, marshalling, pushback, fuel operations |

Additional resources: G04-G07, V03-V05, GS05-GS07.

## Automatic delay/resource handling
When a flight delay is recorded, AGOMS automatically updates all active resource allocations for that flight. The existing allocation start is preserved and its end time is extended by the delay duration. Before committing the extension, the conflict detector checks gates, vehicles and ground staff. If an extended allocation conflicts with another flight, AGOMS automatically searches for a compatible alternative resource combination and updates the same allocation record atomically. The Operations Manager is informed of the automatic action; manual allocation is retained only as an override/exception path.

### Recommended future enhancements
- Priority-aware allocation (emergency/VIP/critical flights first).
- Automatic ground-task creation and rescheduling when a flight schedule changes.
- Resource scoring instead of first-match selection (nearest gate, task capability, utilization and turnaround time).
- Predictive conflict alerts before a delay is applied.
- Audit trail for every automatic allocation/reallocation decision.
- Event-driven notifications for delays, weather warnings and resource conflicts.

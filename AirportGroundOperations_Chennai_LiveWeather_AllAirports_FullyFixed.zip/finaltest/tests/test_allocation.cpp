#include <gtest/gtest.h>
#include "repositories/AirportDatabase.h"
#include "services/FlightService.h"
#include "services/ResourceService.h"
#include "services/AllocationService.h"
#include "utils/Exceptions.h"
#include "test_time_helpers.h"

using namespace agoms;
using namespace agoms::services;

namespace {

struct Fixture {
    repo::AirportDatabase db{":memory:"};
    FlightService flights{db};
    ResourceService resources{db};
    AllocationService allocations{db};

    Fixture() {
        db.initializeSchema();
        flights.createFlight("FA01", "AI900", "CHE", "BOM", "A320",
                              agoms_test::futureTime(60),
                              agoms_test::futureTime(150));
        flights.createFlight("FA02", "AI901", "BOM", "CHE", "A320",
                              agoms_test::futureTime(180),
                              agoms_test::futureTime(270));
        resources.addGate("GA01", "A");
        resources.addVehicle("VA01", "Baggage Tractor");
        resources.addGroundStaffResource("SA01", "Baggage Handling");
        resources.addGroundStaffResource("SA02", "Ramp Agent");
    }

    std::pair<std::string, std::string> futureWindow(int startOffsetMinutes = 60, int durationMinutes = 90) const {
        const auto start = util::DateTime::now().addMinutes(startOffsetMinutes);
        const auto end = start.addMinutes(durationMinutes);
        return {start.toString(), end.toString()};
    }

    AllocationRequest requestFor(const std::string& flightId, std::string start, std::string end,
                                  std::vector<std::string> staff = {"SA01", "SA02"}) {
        AllocationRequest r;
        r.flightId = flightId;
        r.gateId = "GA01";
        r.vehicleId = "VA01";
        r.groundStaffIds = std::move(staff);
        r.windowStart = util::DateTime::fromString(start);
        r.windowEnd = util::DateTime::fromString(end);
        return r;
    }
};

} // namespace

// Test 3: Successful resource allocation
TEST(Allocation, SuccessfulAllocationOccupiesResourcesAndPersistsRecord) {
    Fixture fx;
    const auto w = fx.futureWindow();
    AllocationResult result = fx.allocations.allocate(fx.requestFor("FA01", w.first, w.second));

    ASSERT_TRUE(result.isSuccess());
    ASSERT_FALSE(result.getAllocationId().empty());

    ASSERT_TRUE(fx.resources.getGate("GA01").getStatus() == ResourceStatus::OCCUPIED);
    ASSERT_TRUE(fx.resources.getVehicle("VA01").getStatus() == ResourceStatus::OCCUPIED);
    ASSERT_TRUE(fx.resources.getGroundStaffResource("SA01").getStatus() == ResourceStatus::OCCUPIED);
    ASSERT_TRUE(fx.resources.getGroundStaffResource("SA02").getStatus() == ResourceStatus::OCCUPIED);

    auto allocs = fx.allocations.listAllocationsForFlight("FA01");
    ASSERT_EQ(static_cast<size_t>(1), allocs.size());
}

// Test 4: Gate conflict
TEST(Allocation, OverlappingGateRequestFails) {
    Fixture fx;
    const auto w = fx.futureWindow();
    const auto overlap = fx.futureWindow(90, 45);
    AllocationResult first = fx.allocations.allocate(fx.requestFor("FA01", w.first, w.second));
    ASSERT_TRUE(first.isSuccess());

    // Different flight, same gate, overlapping window -> must fail.
    AllocationRequest second = fx.requestFor("FA02", overlap.first, overlap.second);
    AllocationResult result = fx.allocations.allocate(second);

    ASSERT_FALSE(result.isSuccess());
    ASSERT_TRUE(result.getConflict().getConflictType() == ConflictType::GATE_UNAVAILABLE);
}

// Test 5: Vehicle conflict
TEST(Allocation, OverlappingVehicleRequestFails) {
    Fixture fx;
    fx.resources.addGate("GA02", "B"); // different gate so only the vehicle collides
    const auto w = fx.futureWindow();
    const auto overlap = fx.futureWindow(90, 45);
    AllocationRequest first = fx.requestFor("FA01", w.first, w.second);
    ASSERT_TRUE(fx.allocations.allocate(first).isSuccess());

    AllocationRequest second = fx.requestFor("FA02", overlap.first, overlap.second);
    second.gateId = "GA02"; // avoid the gate conflict so we isolate the vehicle conflict
    AllocationResult result = fx.allocations.allocate(second);

    ASSERT_FALSE(result.isSuccess());
    ASSERT_TRUE(result.getConflict().getConflictType() == ConflictType::VEHICLE_UNAVAILABLE);
}

// Test 6: Ground staff conflict
TEST(Allocation, OverlappingGroundStaffRequestFails) {
    Fixture fx;
    fx.resources.addGate("GA03", "B");
    fx.resources.addVehicle("VA02", "Fuel Truck");
    const auto w = fx.futureWindow();
    const auto overlap = fx.futureWindow(90, 45);

    AllocationRequest first = fx.requestFor("FA01", w.first, w.second, {"SA01"});
    ASSERT_TRUE(fx.allocations.allocate(first).isSuccess());

    AllocationRequest second = fx.requestFor("FA02", overlap.first, overlap.second, {"SA01"});
    second.gateId = "GA03";
    second.vehicleId = "VA02";
    AllocationResult result = fx.allocations.allocate(second);

    ASSERT_FALSE(result.isSuccess());
    ASSERT_TRUE(result.getConflict().getConflictType() == ConflictType::GROUND_STAFF_UNAVAILABLE);
}

TEST(Allocation, NonOverlappingWindowsOnSameGateSucceed) {
    Fixture fx;
    const auto w1 = fx.futureWindow();
    const auto w2 = fx.futureWindow(150, 60);
    AllocationRequest first = fx.requestFor("FA01", w1.first, w1.second, {"SA01"});
    ASSERT_TRUE(fx.allocations.allocate(first).isSuccess());

    AllocationRequest second = fx.requestFor("FA02", w2.first, w2.second, {"SA02"});
    AllocationResult result = fx.allocations.allocate(second);
    ASSERT_TRUE(result.isSuccess());
}

// Test 7: Resource release
TEST(Allocation, ReleaseReturnsResourcesToAvailable) {
    Fixture fx;
    const auto w = fx.futureWindow();
    AllocationResult result = fx.allocations.allocate(fx.requestFor("FA01", w.first, w.second));
    ASSERT_TRUE(result.isSuccess());
    ASSERT_TRUE(fx.resources.getGate("GA01").getStatus() == ResourceStatus::OCCUPIED);

    fx.allocations.release(result.getAllocationId());

    ASSERT_TRUE(fx.resources.getGate("GA01").getStatus() == ResourceStatus::AVAILABLE);
    ASSERT_TRUE(fx.resources.getVehicle("VA01").getStatus() == ResourceStatus::AVAILABLE);
    ASSERT_TRUE(fx.resources.getGroundStaffResource("SA01").getStatus() == ResourceStatus::AVAILABLE);
    ASSERT_TRUE(fx.resources.getGroundStaffResource("SA02").getStatus() == ResourceStatus::AVAILABLE);

    // After release, a new flight should be able to allocate the same gate for the same window.
    AllocationRequest again = fx.requestFor("FA02", w.first, w.second);
    ASSERT_TRUE(fx.allocations.allocate(again).isSuccess());
}

TEST(Allocation, ReleasingAlreadyReleasedAllocationThrows) {
    Fixture fx;
    const auto w = fx.futureWindow();
    AllocationResult result = fx.allocations.allocate(fx.requestFor("FA01", w.first, w.second));
    ASSERT_TRUE(result.isSuccess());
    fx.allocations.release(result.getAllocationId());
    ASSERT_THROW(fx.allocations.release(result.getAllocationId()), ValidationException);
}

TEST(Allocation, UnknownFlightFails) {
    Fixture fx;
    const auto w = fx.futureWindow();
    AllocationRequest req = fx.requestFor("NOT_A_FLIGHT", w.first, w.second);
    AllocationResult result = fx.allocations.allocate(req);
    ASSERT_FALSE(result.isSuccess());
}

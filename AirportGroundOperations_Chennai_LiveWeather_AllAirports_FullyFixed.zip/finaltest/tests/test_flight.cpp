#include <gtest/gtest.h>
#include "repositories/AirportDatabase.h"
#include "services/FlightService.h"
#include "services/AllocationService.h"
#include "services/GroundOperationsService.h"
#include "models/AllocationRequest.h"
#include "utils/Exceptions.h"
#include "test_time_helpers.h"

using namespace agoms;
using namespace agoms::services;

namespace {
repo::AirportDatabase freshDb() {
    repo::AirportDatabase db(":memory:");
    db.initializeSchema();
    return db;
}
}

// Test 1: Flight creation
TEST(FlightCreation, PersistsAndIsRetrievable) {
    repo::AirportDatabase db = freshDb();
    FlightService flightService(db);

    flightService.createFlight("FLX01", "TT100", "CHE", "BOM", "A320",
                                agoms_test::futureTime(60),
                                agoms_test::futureTime(150));

    Flight flight = flightService.getFlight("FLX01");
    ASSERT_EQ(std::string("FLX01"), flight.getFlightId());
    ASSERT_EQ(std::string("TT100"), flight.getFlightNumber());
    ASSERT_TRUE(flight.getStatus() == FlightStatus::SCHEDULED);

    auto schedule = flightService.getSchedule("FLX01");
    ASSERT_TRUE(schedule.has_value());
}

TEST(FlightCreation, DuplicateIdRejected) {
    repo::AirportDatabase db = freshDb();
    FlightService flightService(db);
    flightService.createFlight("FLX02", "TT200", "CHE", "BOM", "A320",
                                agoms_test::futureTime(60),
                                agoms_test::futureTime(150));
    ASSERT_THROW(
        flightService.createFlight("FLX02", "TT201", "CHE", "BOM", "A320",
                                    agoms_test::futureTime(60),
                                    agoms_test::futureTime(150)),
        ValidationException);
}

// Test 8: Flight state transition
TEST(FlightStateTransition, ValidChainSucceeds) {
    repo::AirportDatabase db = freshDb();
    FlightService flightService(db);
    flightService.createFlight("FLX03", "TT300", "CHE", "BOM", "A320",
                                agoms_test::futureTime(60),
                                agoms_test::futureTime(150));

    flightService.transitionFlightStatus("FLX03", FlightStatus::APPROACHING);
    ASSERT_TRUE(flightService.getFlight("FLX03").getStatus() == FlightStatus::APPROACHING);

    flightService.transitionFlightStatus("FLX03", FlightStatus::ARRIVED);
    ASSERT_TRUE(flightService.getFlight("FLX03").getStatus() == FlightStatus::ARRIVED);

    flightService.transitionFlightStatus("FLX03", FlightStatus::GROUND_OPERATIONS);
    WeatherData clearWeather;
    clearWeather.temperatureCelsius = 28.0;
    clearWeather.windSpeedKmh = 10.0;
    clearWeather.visibilityKm = 10.0;
    clearWeather.precipitationMm = 0.0;
    clearWeather.condition = WeatherCondition::CLEAR;
    clearWeather.observedAt = util::DateTime::now();
    clearWeather.airportCode = "CHE";
    db.logWeather(clearWeather);
    WeatherData destinationWeather = clearWeather;
    destinationWeather.airportCode = "BOM";
    db.logWeather(destinationWeather);

    AllocationService allocations(db);
    Gate gate("T-G01", "Test Gate"); db.saveGate(gate);
    Vehicle vehicle("T-V01", "Test Vehicle"); db.saveVehicle(vehicle);
    GroundStaffResource staff("T-S01", "Ramp"); db.saveGroundStaffResource(staff);
    AllocationRequest allocation;
    allocation.flightId = "FLX03"; allocation.gateId = "T-G01"; allocation.vehicleId = "T-V01";
    allocation.groundStaffIds = {"T-S01"};
    const auto allocationStart = util::DateTime::now().addMinutes(60);
    const auto allocationEnd = allocationStart.addMinutes(180);
    allocation.windowStart = allocationStart;
    allocation.windowEnd = allocationEnd;
    ASSERT_TRUE(allocations.allocate(allocation).isSuccess());

    GroundOperationsService groundOps(db);
    auto task = groundOps.createTask("FLX03", TaskType::BAGGAGE_HANDLING, "T-S01",
                                     allocationStart, allocationStart.addMinutes(30));
    groundOps.updateTaskStatus(task.getTaskId(), TaskStatus::IN_PROGRESS, "T-S01");
    groundOps.updateTaskStatus(task.getTaskId(), TaskStatus::COMPLETED, "T-S01");

    flightService.transitionFlightStatus("FLX03", FlightStatus::BOARDING);
    flightService.transitionFlightStatus("FLX03", FlightStatus::READY_FOR_DEPARTURE);
    flightService.transitionFlightStatus("FLX03", FlightStatus::DEPARTED);
    flightService.transitionFlightStatus("FLX03", FlightStatus::COMPLETED);

    ASSERT_TRUE(flightService.getFlight("FLX03").getStatus() == FlightStatus::COMPLETED);
}

TEST(FlightStateTransition, WeatherBlocksChennaiDeparture) {
    repo::AirportDatabase db = freshDb();
    FlightService flightService(db);
    flightService.createFlight("FLXW1", "TW100", "CHE", "BOM", "A320",
                                agoms_test::futureTime(60),
                                agoms_test::futureTime(150));

    flightService.transitionFlightStatus("FLXW1", FlightStatus::APPROACHING);
    flightService.transitionFlightStatus("FLXW1", FlightStatus::ARRIVED);
    flightService.transitionFlightStatus("FLXW1", FlightStatus::GROUND_OPERATIONS);
    flightService.transitionFlightStatus("FLXW1", FlightStatus::BOARDING);

    WeatherData severe;
    severe.temperatureCelsius = 30.0;
    severe.windSpeedKmh = 60.0;
    severe.visibilityKm = 0.5;
    severe.precipitationMm = 30.0;
    severe.condition = WeatherCondition::STORM;
    severe.observedAt = util::DateTime::now();
    severe.airportCode = "CHE";
    db.logWeather(severe);
    WeatherData destination = severe;
    destination.airportCode = "BOM";
    destination.condition = WeatherCondition::CLEAR;
    destination.windSpeedKmh = 10.0;
    destination.visibilityKm = 10.0;
    destination.precipitationMm = 0.0;
    db.logWeather(destination);

    ASSERT_THROW(flightService.transitionFlightStatus("FLXW1", FlightStatus::READY_FOR_DEPARTURE),
                 ValidationException);
}

TEST(FlightStateTransition, ChennaiArrivalNotBlockedByDepartureWeather) {
    repo::AirportDatabase db = freshDb();
    FlightService flightService(db);
    flightService.createFlight("FLXA1", "TA100", "BOM", "CHE", "A320",
                                agoms_test::futureTime(60),
                                agoms_test::futureTime(150));
    flightService.transitionFlightStatus("FLXA1", FlightStatus::APPROACHING);
    flightService.transitionFlightStatus("FLXA1", FlightStatus::ARRIVED);
    ASSERT_TRUE(flightService.getFlight("FLXA1").getStatus() == FlightStatus::ARRIVED);
}

TEST(FlightStateTransition, IllegalTransitionRejected) {
    repo::AirportDatabase db = freshDb();
    FlightService flightService(db);
    flightService.createFlight("FLX04", "TT400", "CHE", "BOM", "A320",
                                agoms_test::futureTime(60),
                                agoms_test::futureTime(150));

    // SCHEDULED -> DEPARTED is not a legal direct transition.
    ASSERT_THROW(flightService.transitionFlightStatus("FLX04", FlightStatus::DEPARTED),
                  InvalidStateTransitionException);
}

TEST(FlightStateTransition, EmergencyPathAllowed) {
    repo::AirportDatabase db = freshDb();
    FlightService flightService(db);
    flightService.createFlight("FLX05", "TT500", "CHE", "BOM", "A320",
                                agoms_test::futureTime(60),
                                agoms_test::futureTime(150));

    flightService.transitionFlightStatus("FLX05", FlightStatus::APPROACHING);
    flightService.transitionFlightStatus("FLX05", FlightStatus::EMERGENCY_LANDING);
    ASSERT_TRUE(flightService.getFlight("FLX05").getStatus() == FlightStatus::EMERGENCY_LANDING);
    flightService.transitionFlightStatus("FLX05", FlightStatus::GROUND_OPERATIONS);
    ASSERT_TRUE(flightService.getFlight("FLX05").getStatus() == FlightStatus::GROUND_OPERATIONS);
}

TEST(FlightService, GetFlightThrowsWhenNotFound) {
    repo::AirportDatabase db = freshDb();
    FlightService flightService(db);
    ASSERT_THROW(flightService.getFlight("DOES_NOT_EXIST"), NotFoundException);
}

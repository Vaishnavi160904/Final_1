#include <gtest/gtest.h>
#include "repositories/AirportDatabase.h"
#include "services/UserService.h"
#include "services/FlightService.h"
#include "services/WeatherService.h"
#include "utils/Exceptions.h"
#include "test_time_helpers.h"

using namespace agoms;
using namespace agoms::services;

namespace { repo::AirportDatabase db(){ repo::AirportDatabase d(":memory:"); d.initializeSchema(); return d; } }

// Functional tests validate complete user-visible business actions without live network dependency.
TEST(Functional, AdministratorCreatesAndUserLogsIn) {
    auto d=db(); UserService us(d);
    us.createOperationsManagerAccount("ops01","ops-pass-1","Operations User");
    auto user=us.login("ops01","ops-pass-1");
    ASSERT_NE(nullptr,user);
    ASSERT_EQ(UserRole::OPERATIONS_MANAGER,user->getRole());
}

TEST(Functional, GroundStaffAccountCanBeCreatedAndAuthenticated) {
    auto d=db(); UserService us(d);
    us.signUpGroundStaff("staff01","staff-pass-1","Ramp User","Ramp");
    auto user=us.login("staff01","staff-pass-1");
    ASSERT_NE(nullptr,user);
    ASSERT_EQ(UserRole::GROUND_STAFF,user->getRole());
    ASSERT_EQ(1u,d.listGroundStaffResources().size());
}

TEST(Functional, ChennaiOnlyFlightRuleIsEnforced) {
    auto d=db(); FlightService fs(d);
    ASSERT_NO_THROW(fs.createFlight("FUN01","FUN001","CHE","BOM","A320",
        agoms_test::futureTime(60),agoms_test::futureTime(120)));
    ASSERT_NO_THROW(fs.createFlight("FUN02","FUN002","BOM","CHE","A320",
        agoms_test::futureTime(180),agoms_test::futureTime(240)));
    ASSERT_THROW(fs.createFlight("FUN03","FUN003","BOM","DEL","A320",
        agoms_test::futureTime(300),agoms_test::futureTime(360)),ValidationException);
}

TEST(Functional, SevereWeatherBlocksChennaiDeparturePlanning) {
    auto d=db(); FlightService fs(d); WeatherService ws(d);
    fs.createFlight("FUN04","FUN004","CHE","BOM","A320",
        agoms_test::futureTime(60),agoms_test::futureTime(120));
    WeatherData w; w.temperatureCelsius=30; w.windSpeedKmh=70; w.visibilityKm=0.4; w.precipitationMm=35;
    w.condition=WeatherCondition::STORM; w.airportCode="CHE"; w.observedAt=util::DateTime::now(); ws.feedWeatherReading(w);
    WeatherData dest=w; dest.airportCode="BOM"; dest.condition=WeatherCondition::CLEAR; dest.windSpeedKmh=10; dest.visibilityKm=10; dest.precipitationMm=0; ws.feedWeatherReading(dest);
    fs.transitionFlightStatus("FUN04",FlightStatus::APPROACHING);
    fs.transitionFlightStatus("FUN04",FlightStatus::ARRIVED);
    fs.transitionFlightStatus("FUN04",FlightStatus::GROUND_OPERATIONS);
    fs.transitionFlightStatus("FUN04",FlightStatus::BOARDING);
    ASSERT_THROW(fs.transitionFlightStatus("FUN04",FlightStatus::READY_FOR_DEPARTURE),ValidationException);
}

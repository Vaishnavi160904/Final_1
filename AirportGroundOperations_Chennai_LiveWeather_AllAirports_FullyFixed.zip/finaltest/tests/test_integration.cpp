#include <gtest/gtest.h>
#include "repositories/AirportDatabase.h"
#include "services/FlightService.h"
#include "services/WeatherService.h"
#include "services/AllocationService.h"
#include "services/DelayService.h"
#include "services/GroundOperationsService.h"
#include "services/EmergencyService.h"
#include "models/AllocationRequest.h"
#include "models/Enums.h"
#include "utils/Exceptions.h"
#include "test_time_helpers.h"

using namespace agoms;
using namespace agoms::services;

namespace {
repo::AirportDatabase db() { repo::AirportDatabase d(":memory:"); d.initializeSchema(); return d; }
util::DateTime t(const char* s) { return util::DateTime::fromString(s); }
void addClearWeather(repo::AirportDatabase& d, const std::string& airport = "CHE") {
    WeatherData w; w.airportCode=airport; w.temperatureCelsius=29; w.windSpeedKmh=12; w.visibilityKm=10; w.precipitationMm=0;
    w.condition=WeatherCondition::CLEAR; w.observedAt=util::DateTime::now(); d.logWeather(w);
}
}

// Integration testing: several real modules collaborate through the repository.
TEST(Integration, FlightWeatherAndAllocationFlowWorksTogether) {
    auto d=db(); FlightService fs(d); WeatherService ws(d); AllocationService as(d);
    fs.createFlight("INT01","INT001","CHE","BOM","A320",agoms_test::futureTime(60),agoms_test::futureTime(150));
    Gate gate("GINT1","Integration Gate"); d.saveGate(gate);
    Vehicle vehicle("VINT1","Integration Bus"); d.saveVehicle(vehicle);
    GroundStaffResource staff("SINT1","Ramp"); d.saveGroundStaffResource(staff);
    addClearWeather(d, "CHE"); addClearWeather(d, "BOM");
    fs.transitionFlightStatus("INT01",FlightStatus::APPROACHING);
    fs.transitionFlightStatus("INT01",FlightStatus::ARRIVED);
    fs.transitionFlightStatus("INT01",FlightStatus::GROUND_OPERATIONS);
    AllocationRequest r; r.flightId="INT01"; r.gateId="GINT1"; r.vehicleId="VINT1"; r.groundStaffIds={"SINT1"}; r.windowStart=agoms_test::futureTime(60); r.windowEnd=agoms_test::futureTime(240);
    auto result=as.allocate(r);
    ASSERT_TRUE(result.isSuccess());
    ASSERT_EQ(1u,d.listAllocationsForFlight("INT01").size());
    GroundOperationsService gs(d);
    auto task = gs.createTask("INT01", TaskType::BAGGAGE_HANDLING, "SINT1", agoms_test::futureTime(60), agoms_test::futureTime(120));
    gs.updateTaskStatus(task.getTaskId(), TaskStatus::IN_PROGRESS, "SINT1");
    gs.updateTaskStatus(task.getTaskId(), TaskStatus::COMPLETED, "SINT1");
    fs.transitionFlightStatus("INT01",FlightStatus::BOARDING);
    fs.transitionFlightStatus("INT01",FlightStatus::READY_FOR_DEPARTURE);
    fs.transitionFlightStatus("INT01",FlightStatus::DEPARTED);
    ASSERT_EQ(FlightStatus::DEPARTED,fs.getFlight("INT01").getStatus());
}

TEST(Integration, DelayUpdatesFlightScheduleAndHistory) {
    auto d=db(); FlightService fs(d); AllocationService as(d); DelayService ds(d,fs,as);
    fs.createFlight("INT02","INT002","CHE","BOM","A320",agoms_test::futureTime(180),agoms_test::futureTime(240));
    auto out=ds.applyDelay("INT02",DelayReason::WEATHER,30,"Integration delay");
    ASSERT_EQ(FlightStatus::DELAYED,fs.getFlight("INT02").getStatus());
    ASSERT_EQ(out.updatedSchedule.getScheduledArrival().addMinutes(30),out.updatedSchedule.getEstimatedArrival());
    ASSERT_EQ(out.updatedSchedule.getScheduledDeparture().addMinutes(30),out.updatedSchedule.getEstimatedDeparture());
    ASSERT_EQ(1u,ds.listDelaysForFlight("INT02").size());
}

TEST(Integration, EmergencyWorkflowUsesFlightAndEmergencyServices) {
    auto d=db(); FlightService fs(d); EmergencyService es(d,fs);
    fs.createFlight("INT03","INT003","BOM","CHE","A320",agoms_test::futureTime(300),agoms_test::futureTime(360));
    fs.transitionFlightStatus("INT03",FlightStatus::APPROACHING);
    auto e=es.declareEmergency("INT03","Medical emergency");
    es.recordLanding(e.getEmergencyId());
    es.beginGroundHandling("INT03",e.getEmergencyId());
    es.resolveEmergency(e.getEmergencyId());
    ASSERT_EQ(FlightStatus::GROUND_OPERATIONS,fs.getFlight("INT03").getStatus());
}

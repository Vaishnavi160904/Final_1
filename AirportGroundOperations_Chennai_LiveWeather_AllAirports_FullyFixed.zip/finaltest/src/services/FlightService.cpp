#include "services/FlightService.h"
#include "utils/Exceptions.h"
#include <cctype>
#include "services/WeatherService.h"
#include "services/ATCService.h"
#include "models/Allocation.h"
#include "models/GroundTask.h"

namespace agoms {
namespace services {

void FlightService::createFlight(const std::string& flightId, const std::string& flightNumber,
                                  const std::string& origin, const std::string& destination,
                                  const std::string& aircraftType, util::DateTime scheduledArrival,
                                  util::DateTime scheduledDeparture) {
    if (flightId.empty() || flightNumber.empty() || origin.empty() || destination.empty() || aircraftType.empty()) {
        throw ValidationException("Flight ID, number, origin, destination and aircraft type are required.");
    }

    std::string normalizedOrigin = origin;
    std::string normalizedDestination = destination;
    for (char& ch : normalizedOrigin) {
        ch = static_cast<char>(std::toupper(static_cast<unsigned char>(ch)));
    }
    for (char& ch : normalizedDestination) {
        ch = static_cast<char>(std::toupper(static_cast<unsigned char>(ch)));
    }

    if (normalizedOrigin == normalizedDestination) {
        throw ValidationException("Origin and destination must be different.");
    }
    if (!WeatherService::isSupportedAirportCode(normalizedOrigin) ||
        !WeatherService::isSupportedAirportCode(normalizedDestination)) {
        throw ValidationException("Unsupported airport code. Use a configured airport code for both source and destination.");
    }

    if (normalizedOrigin != "CHE" && normalizedDestination != "CHE") {
        throw ValidationException(
            "This application is for Chennai Airport. Origin or destination must be CHE (Chennai).");
    }
    if (scheduledArrival.raw() == 0 || scheduledDeparture.raw() == 0 || scheduledArrival >= scheduledDeparture) {
        throw ValidationException("Scheduled arrival must be before scheduled departure.");
    }
    if (scheduledArrival <= util::DateTime::now() || scheduledDeparture <= util::DateTime::now()) {
        throw ValidationException(
            "Flight schedule cannot be in the past. Scheduled arrival and departure must be in the future.");
    }
    if (db_.findFlightById(flightId).has_value()) {
        throw ValidationException("Flight ID already exists: " + flightId);
    }
    for (const auto& existing : db_.listFlights()) {
        if (existing.getFlightNumber() == flightNumber) {
            throw ValidationException("Flight number already exists: " + flightNumber);
        }
    }
    if (db_.findScheduleByFlightId(flightId).has_value()) {
        throw ValidationException("A schedule already exists for flight: " + flightId);
    }

    Flight flight(flightId, flightNumber, normalizedOrigin, normalizedDestination, aircraftType);
    std::string scheduleId = scheduleIdGen_.next();
    FlightSchedule schedule(scheduleId, flightId, scheduledArrival, scheduledDeparture);
    db_.beginTransaction();
    try {
        db_.saveFlight(flight);
        db_.saveFlightSchedule(schedule);
        db_.commitTransaction();
    } catch (...) {
        try { db_.rollbackTransaction(); } catch (...) {}
        throw;
    }
}

Flight FlightService::getFlight(const std::string& flightId) const {
    auto flight = db_.findFlightById(flightId);
    if (!flight.has_value()) {
        throw NotFoundException("Flight not found: " + flightId);
    }
    return flight.value();
}

std::vector<Flight> FlightService::listFlights() const {
    return db_.listFlights();
}

std::optional<FlightSchedule> FlightService::getSchedule(const std::string& flightId) const {
    return db_.findScheduleByFlightId(flightId);
}

void FlightService::transitionFlightStatus(const std::string& flightId, FlightStatus newStatus) {
    Flight flight = getFlight(flightId);

    // Validate the lifecycle transition first. This guarantees that an
    // illegal state transition reports InvalidStateTransitionException even
    // when a departure gate would also be missing prerequisites.
    if (!Flight::isTransitionAllowed(flight.getStatus(), newStatus)) {
        throw InvalidStateTransitionException(
            "Illegal flight state transition for " + flightId + ": " +
            toString(flight.getStatus()) + " -> " + toString(newStatus));
    }

    // A scheduled flight whose departure time has already passed is expired
    // and cannot be moved into an operational state. This prevents an old
    // flight from being run retroactively. Emergency landing is intentionally
    // still permitted for an already-approaching flight because it models an
    // in-progress safety event rather than normal scheduling.
    if (newStatus != FlightStatus::EMERGENCY_LANDING) {
        const auto schedule = db_.findScheduleByFlightId(flightId);
        if (schedule.has_value() && schedule->getScheduledDeparture() <= util::DateTime::now()) {
            throw ValidationException(
                "Flight " + flightId + " has an expired schedule and cannot be operated. "
                "Create a new flight with a future departure time.");
        }
    }

    // Chennai Airport departure planning is weather-gated. Weather is only
    // relevant to flights departing from CHE; an arrival into CHE is not
    // blocked by Chennai departure weather. The Operations Manager must first
    // fetch/feed a current CHE reading.
    const bool departurePlanningStep =
        (newStatus == FlightStatus::READY_FOR_DEPARTURE || newStatus == FlightStatus::DEPARTED);

    if (departurePlanningStep) {
        const std::string origin = flight.getOrigin();
        const std::string destination = flight.getDestination();

        auto requireFreshClearWeather = [&](const std::string& airport, const std::string& label) {
            const auto reading = db_.getLatestWeatherForAirport(airport);
            if (!reading.has_value()) {
                throw ValidationException(
                    "Cannot plan/depart " + flightId + ": current " + label +
                    " weather (" + airport + ") is missing. Fetch weather first.");
            }

            const long ageMinutes = util::DateTime::now().minutesSince(reading->observedAt);
            if (ageMinutes < 0 || ageMinutes > 30) {
                throw ValidationException(
                    label + " weather clearance for " + airport +
                    " is stale (older than 30 minutes). Fetch current weather.");
            }

            const WeatherAlert alert = WeatherService(db_).checkWeatherAlert(reading.value());
            if (alert.level == WeatherAlertLevel::WARNING || alert.level == WeatherAlertLevel::SEVERE) {
                throw ValidationException(
                    "Departure blocked by " + label + " weather at " + airport +
                    ": " + alert.message);
            }
        };

        // Both endpoints are cleared. This is intentionally independent of
        // whether CHE is the source or destination; the application only
        // permits routes involving CHE.
        requireFreshClearWeather(origin, "source");
        requireFreshClearWeather(destination, "destination");

        // A successful allocation is required for the departure operation.
        if (db_.listAllocationsForFlight(flightId).empty()) {
            throw ValidationException("Cannot depart " + flightId + " without an active resource allocation.");
        }
        bool activeAllocation = false;
        for (const auto& allocation : db_.listAllocationsForFlight(flightId)) {
            if (allocation.getStatus() == AllocationStatus::SUCCESS) {
                activeAllocation = true;
                break;
            }
        }
        if (!activeAllocation) {
            throw ValidationException("Cannot depart " + flightId + " without an active resource allocation.");
        }

        // At least one ground task must exist and all tasks must be completed.
        const auto tasks = db_.listTasksForFlight(flightId);
        if (tasks.empty()) {
            throw ValidationException("Cannot depart " + flightId + " until ground operations tasks are completed.");
        }
        for (const auto& task : tasks) {
            if (task.getStatus() != TaskStatus::COMPLETED) {
                throw ValidationException(
                    "Cannot depart " + flightId + ": ground task " + task.getTaskId() +
                    " is not COMPLETED.");
            }
        }

        // The current ATC simulation grants clearance once the flight reaches
        // BOARDING. Re-check it at the final departure gate as a single source
        // of operational clearance.
        ATCService atc(db_);
        if (atc.getATCClearance(flightId) != ATCClearance::GRANTED) {
            throw ValidationException("Cannot depart " + flightId + ": ATC clearance is not GRANTED.");
        }
    }

    flight.transitionTo(newStatus);
    db_.updateFlightStatus(flightId, newStatus);
}

} // namespace services
} // namespace agoms

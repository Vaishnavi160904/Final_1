#include "services/AllocationService.h"
#include "utils/Exceptions.h"
#include "models/Enums.h"

#include <algorithm>

namespace agoms {
namespace services {

AllocationResult AllocationService::allocate(const AllocationRequest& request) {
    if (request.flightId.empty() || request.gateId.empty() || request.vehicleId.empty()) {
        return AllocationResult::failure(ConflictResult(
            ConflictType::INVALID_RESOURCE, "Flight, gate and vehicle IDs are required."));
    }
    if (request.groundStaffIds.empty()) {
        return AllocationResult::failure(ConflictResult(
            ConflictType::INVALID_RESOURCE, "At least one ground staff resource is required."));
    }
    if (request.windowStart.raw() == 0 || request.windowEnd.raw() == 0 ||
        request.windowStart >= request.windowEnd) {
        return AllocationResult::failure(ConflictResult(
            ConflictType::TIME_OVERLAP, "Allocation window start must be before window end."));
    }
    // Resource allocation is planning for a future operational window.
    // Reject a window that has already started so a past flight cannot occupy
    // a gate/vehicle/staff resource retroactively.
    const util::DateTime now = util::DateTime::now();
    if (request.windowStart <= now) {
        return AllocationResult::failure(ConflictResult(
            ConflictType::TIME_OVERLAP,
            "Cannot allocate a previous/current time window. Allocation start must be in the future."));
    }
    // Reject duplicate staff IDs in a single allocation request.
    auto sortedStaff = request.groundStaffIds;
    std::sort(sortedStaff.begin(), sortedStaff.end());
    if (std::adjacent_find(sortedStaff.begin(), sortedStaff.end()) != sortedStaff.end()) {
        return AllocationResult::failure(ConflictResult(
            ConflictType::INVALID_RESOURCE, "A ground staff resource cannot be listed more than once."));
    }

    auto flightOpt = db_.findFlightById(request.flightId);
    if (!flightOpt.has_value()) {
        return AllocationResult::failure(
            ConflictResult(ConflictType::INVALID_RESOURCE, "Unknown flight ID: " + request.flightId));
    }
    Flight flight = flightOpt.value();
    static const FlightStatus allocatableStates[] = {
        FlightStatus::SCHEDULED, FlightStatus::APPROACHING, FlightStatus::ARRIVED,
        FlightStatus::EMERGENCY_LANDING, FlightStatus::GROUND_OPERATIONS, FlightStatus::BOARDING, FlightStatus::DELAYED
    };
    bool statusOk = false;
    for (auto s : allocatableStates) if (s == flight.getStatus()) { statusOk = true; break; }
    if (!statusOk) {
        return AllocationResult::failure(ConflictResult(ConflictType::INVALID_FLIGHT_STATE,
            "Flight " + request.flightId + " is in state " + toString(flight.getStatus()) +
            " and cannot receive new resource allocations."));
    }

    // A flight may have multiple non-overlapping allocations, but never two
    // overlapping active allocations for the same flight.
    for (const auto& existing : db_.listAllocationsForFlight(request.flightId)) {
        if (existing.getStatus() == AllocationStatus::SUCCESS &&
            util::timeWindowsOverlap(request.windowStart, request.windowEnd,
                                     existing.getWindowStart(), existing.getWindowEnd())) {
            return AllocationResult::failure(ConflictResult(
                ConflictType::TIME_OVERLAP,
                "Flight " + request.flightId + " already has active allocation " +
                existing.getAllocationId() + " for the requested time window."));
        }
    }

    ConflictResult conflict = conflictDetector_.checkConflict(request);
    if (conflict.hasConflict()) return AllocationResult::failure(conflict);

    const std::string allocationId = allocationIdGen_.next();
    Allocation allocation(allocationId, request.flightId, request.gateId, request.vehicleId,
                          request.groundStaffIds, request.windowStart, request.windowEnd);

    // Resource status changes and allocation persistence must be atomic.
    db_.beginTransaction();
    try {
        db_.updateGateStatus(request.gateId, ResourceStatus::OCCUPIED);
        db_.updateVehicleStatus(request.vehicleId, ResourceStatus::OCCUPIED);
        for (const auto& staffId : request.groundStaffIds) {
            db_.updateGroundStaffResourceStatus(staffId, ResourceStatus::OCCUPIED);
        }
        db_.saveAllocation(allocation);
        db_.commitTransaction();
    } catch (...) {
        try { db_.rollbackTransaction(); } catch (...) {}
        throw;
    }

    return AllocationResult::success(allocationId);
}

void AllocationService::release(const std::string& allocationId) {
    auto allocOpt = db_.findAllocationById(allocationId);
    if (!allocOpt.has_value()) throw NotFoundException("Allocation not found: " + allocationId);
    Allocation allocation = allocOpt.value();
    if (allocation.getStatus() == AllocationStatus::RELEASED) {
        throw ValidationException("Allocation " + allocationId + " is already released.");
    }

    db_.beginTransaction();
    try {
        db_.updateAllocationStatus(allocationId, AllocationStatus::RELEASED);

        // A resource is AVAILABLE only when no other active allocation still
        // reserves it. Preserve MAINTENANCE if an administrator changed it.
        auto gate = db_.findGate(allocation.getGateId());
        if (gate.has_value() && gate->getStatus() == ResourceStatus::OCCUPIED &&
            db_.listActiveAllocationsForGate(allocation.getGateId()).empty()) {
            db_.updateGateStatus(allocation.getGateId(), ResourceStatus::AVAILABLE);
        }
        auto vehicle = db_.findVehicle(allocation.getVehicleId());
        if (vehicle.has_value() && vehicle->getStatus() == ResourceStatus::OCCUPIED &&
            db_.listActiveAllocationsForVehicle(allocation.getVehicleId()).empty()) {
            db_.updateVehicleStatus(allocation.getVehicleId(), ResourceStatus::AVAILABLE);
        }
        for (const auto& staffId : allocation.getGroundStaffIds()) {
            auto staff = db_.findGroundStaffResource(staffId);
            if (staff.has_value() && staff->getStatus() == ResourceStatus::OCCUPIED &&
                db_.listActiveAllocationsForStaff(staffId).empty()) {
                db_.updateGroundStaffResourceStatus(staffId, ResourceStatus::AVAILABLE);
            }
        }
        db_.commitTransaction();
    } catch (...) {
        try { db_.rollbackTransaction(); } catch (...) {}
        throw;
    }
}

} // namespace services
} // namespace agoms

#ifndef AGOMS_WEATHER_DATA_H
#define AGOMS_WEATHER_DATA_H

#include <string>
#include "models/Enums.h"
#include "utils/DateTime.h"

namespace agoms {

// Snapshot of current airport weather conditions.
struct WeatherData {
    // IATA-style airport code for the observation (CHE, BOM, BLR, etc.).
    // Empty values from legacy/manual tests are treated as CHE.
    std::string airportCode = "CHE";
    double temperatureCelsius = 0.0;
    double windSpeedKmh = 0.0;
    double visibilityKm = 0.0;
    double precipitationMm = 0.0;
    WeatherCondition condition = WeatherCondition::CLEAR;
    util::DateTime observedAt;
};

} // namespace agoms

#endif // AGOMS_WEATHER_DATA_H

#ifndef AGOMS_WEATHER_SERVICE_H
#define AGOMS_WEATHER_SERVICE_H

#include <string>
#include <utility>
#include "models/WeatherData.h"
#include "models/WeatherAlert.h"
#include "repositories/AirportDatabase.h"

namespace agoms {
namespace services {

// Weather integration. Current weather is fetched from the Open-Meteo API
// using the selected airport's latitude/longitude and persisted in SQLite.
// No API key is required. Manual feed remains available for deterministic
// testing and severe-weather demonstrations.
class WeatherService {
public:
    explicit WeatherService(repo::AirportDatabase& db) : db_(db) {}

    // Fetches live current conditions for the default project airport (CHE).
    WeatherData getCurrentWeather();

    // Fetches live current conditions for CHE or the other endpoint of a
    // Chennai flight (BOM, BLR, DEL, HYD, COK, CCU, GOI, DXB, SIN).
    WeatherData getCurrentWeatherForAirport(const std::string& airportCode);

    // Parses an Open-Meteo current-weather JSON payload. Kept public so the
    // API mapping can be unit-tested without making a network call.
    static WeatherData parseOpenMeteoResponse(const std::string& json);

    void feedWeatherReading(const WeatherData& data);

    WeatherAlert checkWeatherAlert(const WeatherData& data) const;

    // Returns true when the code has coordinates configured for live weather.
    static bool isSupportedAirportCode(const std::string& airportCode);

private:
    repo::AirportDatabase& db_;

    static std::pair<double, double> coordinatesForAirport(const std::string& airportCode);
    static WeatherCondition mapWeatherCode(int code);
    static double readJsonNumber(const std::string& json, const std::string& key);
};

} // namespace services
} // namespace agoms

#endif // AGOMS_WEATHER_SERVICE_H

#ifndef AGOMS_TEST_TIME_HELPERS_H
#define AGOMS_TEST_TIME_HELPERS_H

#include "utils/DateTime.h"
#include <utility>

namespace agoms_test {
inline std::pair<agoms::util::DateTime, agoms::util::DateTime> futureFlightSchedule(int startOffsetMinutes = 60, int durationMinutes = 90) {
    const auto start = agoms::util::DateTime::now().addMinutes(startOffsetMinutes);
    return {start, start.addMinutes(durationMinutes)};
}
inline agoms::util::DateTime futureTime(int offsetMinutes) {
    return agoms::util::DateTime::now().addMinutes(offsetMinutes);
}
}

#endif

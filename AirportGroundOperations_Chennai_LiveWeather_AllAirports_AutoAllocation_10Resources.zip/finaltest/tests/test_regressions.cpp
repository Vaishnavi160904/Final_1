#include <gtest/gtest.h>
#include "repositories/AirportDatabase.h"
#include "services/FlightService.h"
#include "services/ResourceService.h"
#include "services/AllocationService.h"
#include "services/GroundOperationsService.h"
#include "services/DelayService.h"
#include "services/EmergencyService.h"
#include "services/UserService.h"
#include "services/WeatherService.h"
#include "utils/Exceptions.h"
#include "test_time_helpers.h"

using namespace agoms;
using namespace agoms::services;

namespace {

util::DateTime dt(const char* s) { return util::DateTime::fromString(s); }

struct OpsFixture {
    repo::AirportDatabase db{":memory:"};
    FlightService flights{db};
    ResourceService resources{db};
    AllocationService allocations{db};
    GroundOperationsService tasks{db};
    DelayService delays{db, flights, allocations};

    OpsFixture() {
        db.initializeSchema();
        flights.createFlight("R01", "RX101", "CHE", "BOM", "A320", agoms_test::futureTime(60), agoms_test::futureTime(120));
        flights.createFlight("R02", "RX102", "BOM", "CHE", "A320", agoms_test::futureTime(180), agoms_test::futureTime(240));
        resources.addGate("RG01", "A");
        resources.addGate("RG02", "B");
        resources.addVehicle("RV01", "Baggage Tractor");
        resources.addVehicle("RV02", "Fuel Truck");
        resources.addGroundStaffResource("RS01", "Baggage Handling");
        resources.addGroundStaffResource("RS02", "Ramp Agent");
    }

    AllocationRequest request(const std::string& flight, const std::string& gate = "RG01",
                              const std::string& vehicle = "RV01") {
        AllocationRequest r;
        r.flightId = flight;
        r.gateId = gate;
        r.vehicleId = vehicle;
        r.groundStaffIds = {"RS01"};
        r.windowStart = agoms_test::futureTime(60);
        r.windowEnd = agoms_test::futureTime(120);
        return r;
    }
};

} // namespace


TEST(Database, ServicesCanBeConstructedBeforeExplicitSchemaCall) {
    // Service constructors hydrate persistent ID generators. The repository
    // now creates its idempotent schema during construction, so dependency
    // injection fixtures are safe even when initializeSchema() is called
    // later in the fixture body.
    repo::AirportDatabase db(":memory:");
    FlightService flights(db);
    ResourceService resources(db);
    AllocationService allocations(db);
    GroundOperationsService tasks(db);
    DelayService delays(db, flights, allocations);
    EmergencyService emergencies(db, flights);
    (void)resources; (void)tasks; (void)delays; (void)emergencies;
    ASSERT_TRUE(true);
}

TEST(UserSignup, PublicSignupCreatesGroundStaffAccountAndResource) {
    repo::AirportDatabase db(":memory:");
    UserService users(db);
    auto created = users.signUpGroundStaff("newstaff", "pass1234", "New Staff", "Baggage Handling");
    ASSERT_EQ(UserRole::GROUND_STAFF, created->getRole());
    auto loggedIn = users.login("newstaff", "pass1234");
    ASSERT_EQ(std::string("New Staff"), loggedIn->getFullName());
    const auto* staff = dynamic_cast<const GroundStaff*>(loggedIn.get());
    ASSERT_TRUE(staff != nullptr);
    ASSERT_FALSE(staff->getLinkedResourceId().empty());
    ASSERT_EQ(static_cast<size_t>(1), db.listGroundStaffResources().size());
}

TEST(UserSignup, DuplicateUsernameAndWeakPasswordAreRejected) {
    repo::AirportDatabase db(":memory:");
    UserService users(db);
    users.signUpGroundStaff("newstaff", "pass1234", "New Staff", "Ramp Agent");
    ASSERT_THROW(users.signUpGroundStaff("newstaff", "another", "Other", "Ramp Agent"), ValidationException);
    ASSERT_THROW(users.signUpGroundStaff("other", "123", "Other", "Ramp Agent"), ValidationException);
}

TEST(Allocation, InvalidTimeWindowRejected) {
    OpsFixture fx;
    auto r = fx.request("R01");
    r.windowStart = agoms_test::futureTime(120);
    r.windowEnd = agoms_test::futureTime(60);
    ASSERT_FALSE(fx.allocations.allocate(r).isSuccess());
}

TEST(Allocation, DuplicateOverlappingAllocationForSameFlightRejected) {
    OpsFixture fx;
    ASSERT_TRUE(fx.allocations.allocate(fx.request("R01")).isSuccess());
    auto second = fx.request("R01", "RG02", "RV02");
    ASSERT_FALSE(fx.allocations.allocate(second).isSuccess());
    ASSERT_EQ(static_cast<size_t>(1), fx.allocations.listAllocationsForFlight("R01").size());
}

TEST(Allocation, ReleaseKeepsResourceOccupiedWhenAnotherAllocationUsesIt) {
    OpsFixture fx;
    auto first = fx.request("R01");
    ASSERT_TRUE(fx.allocations.allocate(first).isSuccess());
    auto second = fx.request("R02");
    second.windowStart = agoms_test::futureTime(180);
    second.windowEnd = agoms_test::futureTime(240);
    ASSERT_TRUE(fx.allocations.allocate(second).isSuccess());

    auto allocations = fx.allocations.listAllocationsForFlight("R01");
    ASSERT_EQ(static_cast<size_t>(1), allocations.size());
    fx.allocations.release(allocations[0].getAllocationId());
    ASSERT_EQ(ResourceStatus::OCCUPIED, fx.resources.getGate("RG01").getStatus());
}

TEST(GroundTask, InvalidTimeWindowRejected) {
    OpsFixture fx;
    ASSERT_THROW(fx.tasks.createTask("R01", TaskType::BAGGAGE_HANDLING, "RS01",
                                     agoms_test::futureTime(120), agoms_test::futureTime(60)), ValidationException);
}

TEST(GroundTask, StaffCannotUpdateAnotherStaffMembersTask) {
    OpsFixture fx;
    GroundTask task = fx.tasks.createTask("R01", TaskType::BAGGAGE_HANDLING, "RS01",
                                          agoms_test::futureTime(60), agoms_test::futureTime(90));
    ASSERT_THROW(fx.tasks.updateTaskStatus(task.getTaskId(), TaskStatus::IN_PROGRESS, "RS02"), ValidationException);
    ASSERT_EQ(TaskStatus::ASSIGNED, fx.tasks.listTasksForFlight("R01")[0].getStatus());
}

TEST(GroundTask, IllegalStatusTransitionRejected) {
    OpsFixture fx;
    GroundTask task = fx.tasks.createTask("R01", TaskType::BAGGAGE_HANDLING, "RS01",
                                          agoms_test::futureTime(60), agoms_test::futureTime(90));
    ASSERT_THROW(fx.tasks.updateTaskStatus(task.getTaskId(), TaskStatus::COMPLETED, "RS01"), InvalidStateTransitionException);
}

TEST(GroundTask, UnknownStaffRejected) {
    OpsFixture fx;
    ASSERT_THROW(fx.tasks.createTask("R01", TaskType::BAGGAGE_HANDLING, "UNKNOWN",
                                     agoms_test::futureTime(60), agoms_test::futureTime(90)), NotFoundException);
}

TEST(Emergency, CannotRecordLandingBeforeDeclaration) {
    OpsFixture fx;
    EmergencyService emergencies(fx.db, fx.flights);
    ASSERT_THROW(emergencies.recordLanding("UNKNOWN"), NotFoundException);
}

TEST(Emergency, CannotResolveBeforeGroundHandling) {
    OpsFixture fx;
    EmergencyService emergencies(fx.db, fx.flights);
    fx.flights.transitionFlightStatus("R02", FlightStatus::APPROACHING);
    auto e = emergencies.declareEmergency("R02", "Engine warning");
    ASSERT_THROW(emergencies.resolveEmergency(e.getEmergencyId()), InvalidStateTransitionException);
}

TEST(Emergency, EmptyReasonRejected) {
    OpsFixture fx;
    EmergencyService emergencies(fx.db, fx.flights);
    fx.flights.transitionFlightStatus("R02", FlightStatus::APPROACHING);
    ASSERT_THROW(emergencies.declareEmergency("R02", ""), ValidationException);
}

TEST(Delay, ScheduledFlightCanBeDelayedBeforeOperations) {
    OpsFixture fx;
    auto outcome = fx.delays.applyDelay("R01", DelayReason::WEATHER, 30, "Weather");
    ASSERT_EQ(FlightStatus::DELAYED, fx.flights.getFlight("R01").getStatus());
    ASSERT_EQ(30L, outcome.updatedSchedule.getEstimatedArrival().minutesSince(outcome.updatedSchedule.getScheduledArrival()));
    ASSERT_EQ(static_cast<size_t>(1), fx.delays.listDelaysForFlight("R01").size());
}

TEST(Delay, MultipleDelaysAccumulate) {
    OpsFixture fx;
    fx.flights.transitionFlightStatus("R01", FlightStatus::GROUND_OPERATIONS);
    fx.delays.applyDelay("R01", DelayReason::WEATHER, 20, "Rain");
    fx.delays.applyDelay("R01", DelayReason::ATC, 15, "ATC hold");
    auto schedule = fx.flights.getSchedule("R01");
    ASSERT_TRUE(schedule.has_value());
    ASSERT_EQ(35L, schedule->getEstimatedArrival().minutesSince(schedule->getScheduledArrival()));
    ASSERT_EQ(static_cast<size_t>(2), fx.delays.listDelaysForFlight("R01").size());
}

TEST(FlightCreation, InvalidScheduleRejected) {
    OpsFixture fx;
    ASSERT_THROW(fx.flights.createFlight("R03", "RX103", "CHE", "BOM", "A320",
                                          agoms_test::futureTime(120), agoms_test::futureTime(60)), ValidationException);
}

TEST(FlightCreation, PastScheduleRejected) {
    repo::AirportDatabase db(":memory:");
    FlightService flights(db);
    ASSERT_THROW(flights.createFlight("PAST01", "PAST001", "CHE", "BOM", "A320",
                                      dt("2026-08-08 07:20"), dt("2026-08-08 07:30")),
                 ValidationException);
    ASSERT_FALSE(db.findFlightById("PAST01").has_value());
}

TEST(FlightCreation, DuplicateFlightNumberRejected) {
    OpsFixture fx;
    ASSERT_THROW(fx.flights.createFlight("R03", "RX101", "CHE", "BOM", "A320",
                                          agoms_test::futureTime(120), agoms_test::futureTime(180)), ValidationException);
}

TEST(DateTime, InvalidCalendarDateRejected) {
    ASSERT_EQ(static_cast<std::time_t>(0), dt("2026-02-30 10:00").raw());
}


TEST(Weather, ParsesCurrentObjectInsteadOfCurrentUnits) {
    const std::string json = R"({
        "current_units":{"temperature_2m":"°C","wind_speed_10m":"km/h","visibility":"m","precipitation":"mm","weather_code":"wmo code"},
        "current":{"temperature_2m":29.4,"wind_speed_10m":12.5,"visibility":10000,"precipitation":0.0,"weather_code":1}
    })";
    WeatherData data = WeatherService::parseOpenMeteoResponse(json);
    ASSERT_DOUBLE_EQ(29.4, data.temperatureCelsius);
    ASSERT_DOUBLE_EQ(12.5, data.windSpeedKmh);
    ASSERT_DOUBLE_EQ(10.0, data.visibilityKm);
    ASSERT_DOUBLE_EQ(0.0, data.precipitationMm);
    ASSERT_EQ(WeatherCondition::CLOUDY, data.condition);
}


TEST(Weather, SupportedAirportCodesIncludeBengaluru) {
    ASSERT_TRUE(WeatherService::isSupportedAirportCode("CHE"));
    ASSERT_TRUE(WeatherService::isSupportedAirportCode("BLR"));
    ASSERT_TRUE(WeatherService::isSupportedAirportCode("blr"));
    ASSERT_TRUE(WeatherService::isSupportedAirportCode("BOM"));
    ASSERT_TRUE(WeatherService::isSupportedAirportCode("DEL"));
    ASSERT_FALSE(WeatherService::isSupportedAirportCode("XXX"));
}

TEST(Allocation, PastDateWindowIsRejectedBeforeResourceConflictCheck) {
    OpsFixture fx;
    auto r = fx.request("R01");
    r.windowStart = dt("2026-09-08 09:00");
    r.windowEnd = dt("2026-09-08 10:00");
    const auto result = fx.allocations.allocate(r);
    ASSERT_FALSE(result.isSuccess());
    ASSERT_EQ(ResourceStatus::AVAILABLE, fx.resources.getGate("RG01").getStatus());
    ASSERT_EQ(ResourceStatus::AVAILABLE, fx.resources.getVehicle("RV01").getStatus());
}

TEST(Weather, DestinationAirportWeatherCanBeFetched) {
    repo::AirportDatabase db(":memory:");
    WeatherService weather(db);
    WeatherData bom = weather.parseOpenMeteoResponse(R"({"current":{"temperature_2m":30,"wind_speed_10m":10,"visibility":10000,"precipitation":0,"weather_code":0,"time":"2026-09-09T09:00"}})");
    bom.airportCode = "BOM";
    weather.feedWeatherReading(bom);
    ASSERT_TRUE(db.getLatestWeatherForAirport("BOM").has_value());
}


TEST(FlightDepartureClearance, DestinationWeatherIsRequiredAndFresh) {
    OpsFixture fx;
    fx.flights.transitionFlightStatus("R01", FlightStatus::GROUND_OPERATIONS);

    WeatherData che; che.airportCode="CHE"; che.temperatureCelsius=28; che.windSpeedKmh=10; che.visibilityKm=10; che.precipitationMm=0; che.condition=WeatherCondition::CLEAR; che.observedAt=util::DateTime::now(); fx.db.logWeather(che);
    fx.flights.transitionFlightStatus("R01", FlightStatus::BOARDING);
    ASSERT_THROW(fx.flights.transitionFlightStatus("R01", FlightStatus::READY_FOR_DEPARTURE), ValidationException);

    WeatherData bom=che; bom.airportCode="BOM"; fx.db.logWeather(bom);

    Gate gate("CLR-G1", "A"); fx.db.saveGate(gate);
    Vehicle vehicle("CLR-V1", "Bus"); fx.db.saveVehicle(vehicle);
    GroundStaffResource staff("CLR-S1", "Ramp"); fx.db.saveGroundStaffResource(staff);
    AllocationService allocationService(fx.db);
    AllocationRequest ar; ar.flightId="R01"; ar.gateId="CLR-G1"; ar.vehicleId="CLR-V1";
    ar.groundStaffIds={"CLR-S1"}; ar.windowStart=agoms_test::futureTime(60); ar.windowEnd=agoms_test::futureTime(240);
    ASSERT_TRUE(allocationService.allocate(ar).isSuccess());

    auto task = fx.tasks.createTask("R01", TaskType::BAGGAGE_HANDLING, "CLR-S1",
                                     agoms_test::futureTime(60), agoms_test::futureTime(120));
    fx.tasks.updateTaskStatus(task.getTaskId(), TaskStatus::IN_PROGRESS, "CLR-S1");
    fx.tasks.updateTaskStatus(task.getTaskId(), TaskStatus::COMPLETED, "CLR-S1");

    ASSERT_NO_THROW(fx.flights.transitionFlightStatus("R01", FlightStatus::READY_FOR_DEPARTURE));
}

TEST(FlightDepartureClearance, AllocationAndGroundTasksAreRequired) {
    repo::AirportDatabase db(":memory:");
    FlightService fs(db);
    fs.createFlight("CLR01","CLR001","CHE","BOM","A320",agoms_test::futureTime(60),agoms_test::futureTime(120));
    WeatherData w; w.airportCode="CHE"; w.windSpeedKmh=10; w.visibilityKm=10; w.condition=WeatherCondition::CLEAR; w.observedAt=util::DateTime::now(); db.logWeather(w);
    w.airportCode="BOM"; db.logWeather(w);
    fs.transitionFlightStatus("CLR01",FlightStatus::GROUND_OPERATIONS);
    fs.transitionFlightStatus("CLR01",FlightStatus::BOARDING);
    ASSERT_THROW(fs.transitionFlightStatus("CLR01",FlightStatus::READY_FOR_DEPARTURE), ValidationException);
}

TEST(FlightCreation, NonChennaiRouteRejected) {
    OpsFixture fx;
    ASSERT_THROW(fx.flights.createFlight("R04", "RX104", "DEL", "BOM", "A320",
                                          agoms_test::futureTime(120), agoms_test::futureTime(180)), ValidationException);
}


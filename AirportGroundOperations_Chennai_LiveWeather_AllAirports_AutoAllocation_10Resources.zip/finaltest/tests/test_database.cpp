#include <gtest/gtest.h>
#include "repositories/AirportDatabase.h"
#include "services/FlightService.h"
#include "services/UserService.h"
#include "utils/Exceptions.h"
#include <cstdio>
#include "test_time_helpers.h"

using namespace agoms;
using namespace agoms::services;

// Test 11: Database persistence
// Verifies that data survives closing and re-opening the SAME on-disk
// SQLite file (as opposed to an in-memory ":memory:" database, which is
// used by the other test files for fast, isolated tests).
TEST(Database, DataSurvivesReopen) {
    const std::string path = "test_persistence_tmp.db";
    std::remove(path.c_str());

    {
        repo::AirportDatabase db(path);
        db.initializeSchema();
        FlightService flights(db);
        flights.createFlight("FP01", "AI999", "CHE", "GOI", "A321",
                              agoms_test::futureTime(60),
                              agoms_test::futureTime(150));
        flights.transitionFlightStatus("FP01", FlightStatus::GROUND_OPERATIONS);
    } // db goes out of scope here -> connection closed, file flushed to disk

    {
        repo::AirportDatabase db(path);
        db.initializeSchema(); // idempotent; tables already exist
        FlightService flights(db);
        Flight flight = flights.getFlight("FP01");
        ASSERT_EQ(std::string("FP01"), flight.getFlightId());
        ASSERT_TRUE(flight.getStatus() == FlightStatus::GROUND_OPERATIONS);
    }

    std::remove(path.c_str());
}

TEST(Database, SeedDataIsIdempotent) {
    const std::string path = "test_seed_tmp.db";
    std::remove(path.c_str());

    {
        repo::AirportDatabase db(path);
        db.initializeSchema();
        db.seedSampleDataIfEmpty();
    }
    {
        // Re-opening and seeding again must not throw or duplicate rows,
        // since seedSampleDataIfEmpty() checks the flights table first.
        repo::AirportDatabase db(path);
        db.initializeSchema();
        db.seedSampleDataIfEmpty();
        auto flights = db.listFlights();
        ASSERT_EQ(static_cast<size_t>(3), flights.size()); // FL001, FL002, FL003 only, not duplicated
    }

    std::remove(path.c_str());
}

TEST(Database, UserAuthenticationRoundTrips) {
    repo::AirportDatabase db(":memory:");
    db.initializeSchema();
    UserService users(db);
    users.createOperationsManager("UX01", "opstest", "secret123", "Test Manager");

    auto user = users.login("opstest", "secret123");
    ASSERT_EQ(std::string("Test Manager"), user->getFullName());
    ASSERT_TRUE(user->getRole() == UserRole::OPERATIONS_MANAGER);

    ASSERT_THROW(users.login("opstest", "wrongpassword"), AuthenticationException);
    ASSERT_THROW(users.login("nosuchuser", "secret123"), AuthenticationException);
}

// WeatherService tests avoid the external network. The API response mapping is
// tested with a representative Open-Meteo JSON payload, while database
// persistence is tested with manual readings.
#include "services/WeatherService.h"

TEST(Weather, FeedWritesExactReadingToDatabase) {
    repo::AirportDatabase db(":memory:");
    db.initializeSchema();
    WeatherService weather(db);

    WeatherData fed;
    fed.temperatureCelsius = 31.5;
    fed.windSpeedKmh = 12.0;
    fed.visibilityKm = 9.0;
    fed.precipitationMm = 0.0;
    fed.condition = WeatherCondition::CLEAR;
    fed.observedAt = util::DateTime::fromString("2026-09-05 08:00");

    weather.feedWeatherReading(fed);

    auto latest = db.getLatestWeather();
    ASSERT_TRUE(latest.has_value());
    ASSERT_EQ(31.5, latest->temperatureCelsius);
    ASSERT_EQ(12.0, latest->windSpeedKmh);
    ASSERT_TRUE(latest->condition == WeatherCondition::CLEAR);
}

TEST(Weather, OpenMeteoJsonIsMappedCorrectly) {
    const std::string json =
        R"({"current":{"time":"2026-09-08T16:45","temperature_2m":33.2,"wind_speed_10m":22.4,"visibility":8500,"precipitation":2.5,"weather_code":61}})";

    WeatherData data = WeatherService::parseOpenMeteoResponse(json);
    ASSERT_DOUBLE_EQ(33.2, data.temperatureCelsius);
    ASSERT_DOUBLE_EQ(22.4, data.windSpeedKmh);
    ASSERT_DOUBLE_EQ(8.5, data.visibilityKm);
    ASSERT_DOUBLE_EQ(2.5, data.precipitationMm);
    ASSERT_TRUE(data.condition == WeatherCondition::RAIN);
}

TEST(Weather, OpenMeteoStormCodeMapsToStorm) {
    const std::string json =
        R"({"current":{"temperature_2m":29.0,"wind_speed_10m":55.0,"visibility":500,"precipitation":12.0,"weather_code":95}})";
    WeatherData data = WeatherService::parseOpenMeteoResponse(json);
    ASSERT_TRUE(data.condition == WeatherCondition::STORM);
}

TEST(Weather, MissingApiFieldIsRejected) {
    const std::string json =
        R"({"current":{"temperature_2m":29.0,"wind_speed_10m":12.0}})";
    ASSERT_THROW(WeatherService::parseOpenMeteoResponse(json), ExternalServiceException);
}

TEST(Weather, EveryManualFeedIsPersistedAsHistory) {
    repo::AirportDatabase db(":memory:");
    db.initializeSchema();
    WeatherService weather(db);

    WeatherData first;
    first.temperatureCelsius = 20.0;
    first.condition = WeatherCondition::CLOUDY;
    first.observedAt = util::DateTime::fromString("2026-09-05 08:00");
    weather.feedWeatherReading(first);

    WeatherData second;
    second.temperatureCelsius = 38.0;
    second.condition = WeatherCondition::STORM;
    second.observedAt = util::DateTime::fromString("2026-09-05 09:00");
    weather.feedWeatherReading(second);

    auto latest = db.getLatestWeather();
    ASSERT_TRUE(latest.has_value());
    ASSERT_EQ(38.0, latest->temperatureCelsius);
    ASSERT_TRUE(latest->condition == WeatherCondition::STORM);
}

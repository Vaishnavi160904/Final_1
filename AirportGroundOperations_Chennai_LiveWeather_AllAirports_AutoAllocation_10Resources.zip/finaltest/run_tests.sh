#!/usr/bin/env bash
set -euo pipefail
rm -rf build
echo "[1/3] Configuring with GoogleTest..."
cmake -S . -B build -DAGOMS_BUILD_TESTS=ON
echo "[2/3] Building application and tests..."
cmake --build build -j2
echo "[3/3] Running all GoogleTest cases..."
ctest --test-dir build --output-on-failure

#include "services/WeatherService.h"
#include "utils/Exceptions.h"

#include <curl/curl.h>
#include <cctype>
#include <cstdlib>
#include <sstream>
#include <stdexcept>

namespace agoms {
namespace services {
namespace {

struct CurlGlobalInitializer {
    CurlGlobalInitializer() { curl_global_init(CURL_GLOBAL_DEFAULT); }
    ~CurlGlobalInitializer() { curl_global_cleanup(); }
};

CurlGlobalInitializer curlInitializer;

size_t writeCallback(char* ptr, size_t size, size_t nmemb, void* userdata) {
    auto* output = static_cast<std::string*>(userdata);
    output->append(ptr, size * nmemb);
    return size * nmemb;
}

std::string upperCopy(std::string value) {
    for (char& ch : value) ch = static_cast<char>(std::toupper(static_cast<unsigned char>(ch)));
    return value;
}

std::string readJsonString(const std::string& json, const std::string& key, std::size_t startPos) {
    const std::string needle = "\"" + key + "\"";
    const std::size_t keyPos = json.find(needle, startPos);
    if (keyPos == std::string::npos) return {};
    const std::size_t colon = json.find(':', keyPos + needle.size());
    if (colon == std::string::npos) return {};
    std::size_t pos = colon + 1;
    while (pos < json.size() && std::isspace(static_cast<unsigned char>(json[pos]))) ++pos;
    if (pos >= json.size() || json[pos] != '"') return {};
    ++pos;
    const std::size_t end = json.find('"', pos);
    if (end == std::string::npos) return {};
    return json.substr(pos, end - pos);
}

std::string fetchUrl(const std::string& url) {
    CURL* curl = curl_easy_init();
    if (!curl) throw ExternalServiceException("Unable to initialize HTTP client.");

    std::string response;
    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
    curl_easy_setopt(curl, CURLOPT_TIMEOUT, 10L);
    curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT, 5L);
    curl_easy_setopt(curl, CURLOPT_USERAGENT, "AGOMS/1.0");
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, writeCallback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &response);

    const CURLcode result = curl_easy_perform(curl);
    long httpCode = 0;
    curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &httpCode);
    curl_easy_cleanup(curl);

    if (result != CURLE_OK) {
        throw ExternalServiceException(
            std::string("Weather API request failed: ") + curl_easy_strerror(result));
    }
    if (httpCode < 200 || httpCode >= 300) {
        throw ExternalServiceException("Weather API returned HTTP status " + std::to_string(httpCode) + ".");
    }
    if (response.empty()) throw ExternalServiceException("Weather API returned an empty response.");
    return response;
}

} // namespace

WeatherData WeatherService::getCurrentWeather() {
    return getCurrentWeatherForAirport("CHE");
}

WeatherData WeatherService::getCurrentWeatherForAirport(const std::string& airportCode) {
    const auto coordinates = coordinatesForAirport(airportCode);
    const std::string url =
        "https://api.open-meteo.com/v1/forecast?latitude=" + std::to_string(coordinates.first) +
        "&longitude=" + std::to_string(coordinates.second) +
        "&current=temperature_2m,wind_speed_10m,visibility,precipitation,weather_code"
        "&temperature_unit=celsius&wind_speed_unit=kmh&precipitation_unit=mm&timezone=auto";

    WeatherData data = parseOpenMeteoResponse(fetchUrl(url));
    data.airportCode = upperCopy(airportCode);
    db_.logWeather(data);
    return data;
}

WeatherData WeatherService::parseOpenMeteoResponse(const std::string& json) {
    WeatherData data;
    data.temperatureCelsius = readJsonNumber(json, "temperature_2m");
    data.windSpeedKmh = readJsonNumber(json, "wind_speed_10m");
    data.visibilityKm = readJsonNumber(json, "visibility") / 1000.0;
    data.precipitationMm = readJsonNumber(json, "precipitation");
    const int weatherCode = static_cast<int>(readJsonNumber(json, "weather_code"));
    data.condition = mapWeatherCode(weatherCode);

    // Open-Meteo's current.time is already in the requested airport
    // timezone (timezone=auto). Use that observation time instead of the
    // machine's UTC clock, which previously caused Chennai readings such as
    // 23:15 IST to be displayed as 17:45.
    const std::string observedTime = readJsonString(json, "time", json.find("\"current\""));
    if (!observedTime.empty()) {
        std::string normalized = observedTime;
        const std::size_t separator = normalized.find('T');
        if (separator != std::string::npos) normalized[separator] = ' ';
        data.observedAt = util::DateTime::fromString(normalized);
        if (data.observedAt.raw() == 0) data.observedAt = util::DateTime::now();
    } else {
        data.observedAt = util::DateTime::now();
    }
    return data;
}

void WeatherService::feedWeatherReading(const WeatherData& data) {
    WeatherData normalized = data;
    if (normalized.airportCode.empty()) normalized.airportCode = "CHE";
    normalized.airportCode = upperCopy(normalized.airportCode);
    // Validate that manual readings use a known airport code.
    (void)coordinatesForAirport(normalized.airportCode);
    db_.logWeather(normalized);
}

bool WeatherService::isSupportedAirportCode(const std::string& airportCode) {
    const std::string code = upperCopy(airportCode);
    return code == "CHE" || code == "BOM" || code == "BLR" || code == "DEL" ||
           code == "HYD" || code == "COK" || code == "CCU" || code == "GOI" ||
           code == "DXB" || code == "SIN";
}

std::pair<double, double> WeatherService::coordinatesForAirport(const std::string& airportCode) {
    const std::string code = upperCopy(airportCode);
    // Chennai is the home airport, but destination/source weather must also
    // be checked for the other endpoint of a Chennai flight.
    if (code == "CHE") return {12.9941, 80.1709}; // Chennai
    if (code == "BOM") return {19.0896, 72.8656}; // Mumbai
    if (code == "BLR") return {13.1986, 77.7066}; // Bengaluru
    if (code == "DEL") return {28.5562, 77.1000}; // Delhi
    if (code == "HYD") return {17.2403, 78.4294}; // Hyderabad
    if (code == "COK") return {10.1520, 76.4019}; // Kochi
    if (code == "CCU") return {22.6547, 88.4467}; // Kolkata
    if (code == "GOI") return {15.3800, 73.8310}; // Goa
    if (code == "DXB") return {25.2532, 55.3657}; // Dubai
    if (code == "SIN") return {1.3644, 103.9915}; // Singapore
    throw ValidationException("Unsupported airport code: " + code + ". Supported codes: CHE, BOM, BLR, DEL, HYD, COK, CCU, GOI, DXB, SIN.");
}

WeatherCondition WeatherService::mapWeatherCode(int code) {
    if (code == 0) return WeatherCondition::CLEAR;
    if (code >= 1 && code <= 3) return WeatherCondition::CLOUDY;
    if (code == 45 || code == 48) return WeatherCondition::FOG;
    if ((code >= 51 && code <= 67) || (code >= 80 && code <= 82)) return WeatherCondition::RAIN;
    if ((code >= 71 && code <= 77) || code == 85 || code == 86) return WeatherCondition::SNOW;
    if (code == 95 || code == 96 || code == 99) return WeatherCondition::STORM;
    return WeatherCondition::CLOUDY;
}

double WeatherService::readJsonNumber(const std::string& json, const std::string& key) {
    // Open-Meteo returns the same variable names in both `current_units` and
    // `current`. Searching the complete JSON can therefore find a unit string
    // such as "temperature_2m": "°C" before the numeric current value.
    // Restrict the search to the `current` object to avoid that bug.
    const std::string currentMarker = "\"current\"";
    const std::size_t currentPos = json.find(currentMarker);
    if (currentPos == std::string::npos) {
        throw ExternalServiceException("Weather API response is missing the current weather object.");
    }

    const std::string needle = "\"" + key + "\"";
    const std::size_t keyPos = json.find(needle, currentPos + currentMarker.size());
    if (keyPos == std::string::npos) {
        throw ExternalServiceException("Weather API response is missing field: " + key);
    }

    const std::size_t colon = json.find(':', keyPos + needle.size());
    if (colon == std::string::npos) {
        throw ExternalServiceException("Invalid weather API response near field: " + key);
    }

    std::size_t pos = colon + 1;
    while (pos < json.size() && std::isspace(static_cast<unsigned char>(json[pos]))) ++pos;
    if (json.compare(pos, 4, "null") == 0) {
        throw ExternalServiceException("Weather API returned null for field: " + key);
    }

    char* end = nullptr;
    const double value = std::strtod(json.c_str() + pos, &end);
    if (end == json.c_str() + pos) {
        throw ExternalServiceException("Invalid numeric value in weather API field: " + key);
    }
    return value;
}

WeatherAlert WeatherService::checkWeatherAlert(const WeatherData& data) const {
    WeatherAlert alert;

    if (data.condition == WeatherCondition::STORM || data.windSpeedKmh >= 50.0 ||
        data.visibilityKm < 1.0) {
        alert.level = WeatherAlertLevel::SEVERE;
        alert.message = "Severe conditions: high wind/storm or very low visibility. "
                        "Ground operations and departures may need to be suspended.";
    } else if (data.condition == WeatherCondition::FOG || data.windSpeedKmh >= 35.0 ||
               data.visibilityKm < 3.0 || data.precipitationMm >= 20.0) {
        alert.level = WeatherAlertLevel::WARNING;
        alert.message = "Degraded conditions (fog/high wind/heavy precipitation). "
                        "Expect possible delays.";
    } else if (data.windSpeedKmh >= 20.0 || data.precipitationMm >= 10.0) {
        alert.level = WeatherAlertLevel::ADVISORY;
        alert.message = "Minor weather advisory; monitor conditions.";
    } else {
        alert.level = WeatherAlertLevel::NONE;
        alert.message = "Conditions normal.";
    }
    return alert;
}

} // namespace services
} // namespace agoms

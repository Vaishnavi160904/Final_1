#include "services/UserService.h"
#include "models/AirportAdministrator.h"
#include "models/OperationsManager.h"
#include "models/GroundStaff.h"
#include "models/GroundStaffResource.h"
#include "utils/Exceptions.h"
#include <algorithm>
#include <cctype>
#include <iomanip>
#include <sstream>

namespace agoms {
namespace services {

namespace {

int numericSuffix(const std::string& id, const std::string& prefix) {
    if (id.size() <= prefix.size() || id.compare(0, prefix.size(), prefix) != 0) return 0;
    const std::string suffix = id.substr(prefix.size());
    if (suffix.empty() || !std::all_of(suffix.begin(), suffix.end(),
                                        [](unsigned char c) { return std::isdigit(c) != 0; })) {
        return 0;
    }
    return std::stoi(suffix);
}

std::string nextId(const std::string& prefix, const std::vector<std::string>& ids) {
    int maximum = 0;
    for (const auto& id : ids) maximum = std::max(maximum, numericSuffix(id, prefix));
    std::ostringstream oss;
    oss << prefix << std::setw(4) << std::setfill('0') << (maximum + 1);
    return oss.str();
}

} // namespace

std::unique_ptr<User> UserService::login(const std::string& username, const std::string& password) {
    auto found = db_.findUserByUsername(username);
    if (!found.has_value()) {
        throw AuthenticationException("No such user: " + username);
    }
    std::unique_ptr<User> user = std::move(found.value());
    if (!user->isActive()) {
        throw AuthenticationException("Account is deactivated: " + username);
    }
    if (!user->verifyPassword(password)) {
        throw AuthenticationException("Incorrect password for user: " + username);
    }
    return user;
}

void UserService::createAdministrator(const std::string& userId, const std::string& username,
                                       const std::string& password, const std::string& fullName) {
    AirportAdministrator admin(userId, username, "", fullName);
    admin.setPassword(password);
    db_.saveUser(admin);
}

void UserService::createOperationsManager(const std::string& userId, const std::string& username,
                                           const std::string& password, const std::string& fullName) {
    OperationsManager mgr(userId, username, "", fullName);
    mgr.setPassword(password);
    db_.saveUser(mgr);
}

void UserService::createGroundStaff(const std::string& userId, const std::string& username,
                                     const std::string& password, const std::string& fullName,
                                     const std::string& linkedResourceId) {
    GroundStaff staff(userId, username, "", fullName, linkedResourceId);
    staff.setPassword(password);
    db_.saveUser(staff);
}

std::unique_ptr<User> UserService::createOperationsManagerAccount(
    const std::string& username, const std::string& password, const std::string& fullName) {
    if (username.empty() || password.empty() || fullName.empty()) {
        throw ValidationException("Username, password and full name are required.");
    }
    if (password.size() < 4) {
        throw ValidationException("Password must contain at least 4 characters.");
    }
    if (db_.findUserByUsername(username).has_value()) {
        throw ValidationException("Username already exists: " + username);
    }

    std::vector<std::string> userIds;
    for (const auto& user : db_.listUsers()) userIds.push_back(user->getUserId());
    const std::string userId = nextId("U", userIds);

    OperationsManager manager(userId, username, "", fullName);
    manager.setPassword(password);
    db_.saveUser(manager);
    return std::make_unique<OperationsManager>(manager);
}

std::unique_ptr<User> UserService::createGroundStaffAccount(
    const std::string& username, const std::string& password,
    const std::string& fullName, const std::string& specialization) {
    if (username.empty() || password.empty() || fullName.empty()) {
        throw ValidationException("Username, password and full name are required.");
    }
    if (password.size() < 4) {
        throw ValidationException("Password must contain at least 4 characters.");
    }
    if (db_.findUserByUsername(username).has_value()) {
        throw ValidationException("Username already exists: " + username);
    }

    std::vector<std::string> userIds;
    for (const auto& user : db_.listUsers()) userIds.push_back(user->getUserId());
    std::vector<std::string> staffIds;
    for (const auto& staff : db_.listGroundStaffResources()) staffIds.push_back(staff.getResourceId());

    const std::string userId = nextId("U", userIds);
    const std::string resourceId = nextId("GS", staffIds);
    const std::string finalSpecialization = specialization.empty()
        ? "General Ground Operations" : specialization;

    GroundStaff staff(userId, username, "", fullName, resourceId);
    staff.setPassword(password);
    GroundStaffResource resource(resourceId, finalSpecialization);

    db_.beginTransaction();
    try {
        db_.saveGroundStaffResource(resource);
        db_.saveUser(staff);
        db_.commitTransaction();
    } catch (...) {
        try { db_.rollbackTransaction(); } catch (...) {}
        throw;
    }

    return std::make_unique<GroundStaff>(staff);
}

std::unique_ptr<User> UserService::signUpGroundStaff(
    const std::string& username, const std::string& password,
    const std::string& fullName, const std::string& specialization) {
    return createGroundStaffAccount(username, password, fullName, specialization);
}

std::vector<std::unique_ptr<User>> UserService::listUsers() {
    return db_.listUsers();
}

} // namespace services
} // namespace agoms

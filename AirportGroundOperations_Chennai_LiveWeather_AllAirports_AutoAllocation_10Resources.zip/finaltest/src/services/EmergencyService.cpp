#include "services/EmergencyService.h"
#include "utils/Exceptions.h"

namespace agoms {
namespace services {

EmergencyLanding EmergencyService::declareEmergency(const std::string& flightId, const std::string& reason) {
    if (reason.empty()) throw ValidationException("Emergency reason is required.");
    Flight flight = flightService_.getFlight(flightId);
    if (flight.getStatus() != FlightStatus::APPROACHING) {
        throw InvalidStateTransitionException(
            "Emergency can be declared only for an APPROACHING flight; current state is " +
            toString(flight.getStatus()) + ".");
    }

    const std::string emergencyId = emergencyIdGen_.next();
    EmergencyLanding emergency(emergencyId, flightId, reason, util::DateTime::now());
    db_.beginTransaction();
    try {
        flightService_.transitionFlightStatus(flightId, FlightStatus::EMERGENCY_LANDING);
        db_.saveEmergency(emergency);
        db_.commitTransaction();
    } catch (...) {
        try { db_.rollbackTransaction(); } catch (...) {}
        throw;
    }
    return emergency;
}

EmergencyLanding EmergencyService::recordLanding(const std::string& emergencyId) {
    EmergencyLanding emergency = getEmergency(emergencyId);
    if (emergency.getStatus() != EmergencyStatus::DECLARED) {
        throw InvalidStateTransitionException("Landing can be recorded only from DECLARED status.");
    }
    Flight flight = flightService_.getFlight(emergency.getFlightId());
    if (flight.getStatus() != FlightStatus::EMERGENCY_LANDING) {
        throw InvalidStateTransitionException("Flight is not in EMERGENCY_LANDING state.");
    }
    emergency.recordLanding(util::DateTime::now());
    db_.updateEmergency(emergency);
    return emergency;
}

void EmergencyService::beginGroundHandling(const std::string& flightId, const std::string& emergencyId) {
    EmergencyLanding emergency = getEmergency(emergencyId);
    if (emergency.getFlightId() != flightId) {
        throw ValidationException("Emergency " + emergencyId + " does not belong to flight " + flightId);
    }
    if (emergency.getStatus() != EmergencyStatus::LANDED) {
        throw InvalidStateTransitionException("Ground handling can begin only after landing.");
    }
    Flight flight = flightService_.getFlight(flightId);
    if (flight.getStatus() != FlightStatus::EMERGENCY_LANDING) {
        throw InvalidStateTransitionException("Flight must be in EMERGENCY_LANDING before ground handling.");
    }

    db_.beginTransaction();
    try {
        flightService_.transitionFlightStatus(flightId, FlightStatus::GROUND_OPERATIONS);
        emergency.updateStatus(EmergencyStatus::GROUND_HANDLING);
        db_.updateEmergency(emergency);
        db_.commitTransaction();
    } catch (...) {
        try { db_.rollbackTransaction(); } catch (...) {}
        throw;
    }
}

void EmergencyService::resolveEmergency(const std::string& emergencyId) {
    EmergencyLanding emergency = getEmergency(emergencyId);
    if (emergency.getStatus() != EmergencyStatus::GROUND_HANDLING) {
        throw InvalidStateTransitionException("Emergency can be resolved only after ground handling.");
    }
    emergency.updateStatus(EmergencyStatus::RESOLVED);
    db_.updateEmergency(emergency);
}

EmergencyLanding EmergencyService::getEmergency(const std::string& emergencyId) const {
    for (const auto& e : db_.listAllEmergencies()) {
        if (e.getEmergencyId() == emergencyId) return e;
    }
    throw NotFoundException("Emergency record not found: " + emergencyId);
}

} // namespace services
} // namespace agoms

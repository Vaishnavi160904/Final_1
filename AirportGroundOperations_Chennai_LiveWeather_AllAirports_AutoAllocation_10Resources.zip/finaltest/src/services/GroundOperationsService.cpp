#include "services/GroundOperationsService.h"
#include "utils/Exceptions.h"

namespace agoms {
namespace services {

GroundTask GroundOperationsService::createTask(const std::string& flightId, TaskType type,
                                                const std::string& assignedStaffId,
                                                util::DateTime start, util::DateTime end) {
    if (!db_.findFlightById(flightId).has_value()) {
        throw NotFoundException("Cannot create ground task; unknown flight: " + flightId);
    }
    if (start.raw() == 0 || end.raw() == 0 || start >= end) {
        throw ValidationException("Ground task start time must be before end time.");
    }
    if (!assignedStaffId.empty()) {
        auto staff = db_.findGroundStaffResource(assignedStaffId);
        if (!staff.has_value()) throw NotFoundException("Ground staff resource not found: " + assignedStaffId);
        if (staff->getStatus() == ResourceStatus::MAINTENANCE) {
            throw ResourceUnavailableException("Ground staff " + assignedStaffId + " is under MAINTENANCE.");
        }
        for (const auto& task : db_.listTasksForStaff(assignedStaffId)) {
            if (util::timeWindowsOverlap(start, end, task.getStartTime(), task.getEndTime()) &&
                task.getStatus() != TaskStatus::COMPLETED) {
                throw AllocationConflictException(
                    "Ground staff " + assignedStaffId + " already has overlapping task " + task.getTaskId() + ".");
            }
        }
    }
    std::string taskId = taskIdGen_.next();
    GroundTask task(taskId, flightId, type, assignedStaffId, start, end);
    db_.saveGroundTask(task);
    return task;
}

void GroundOperationsService::updateTaskStatus(const std::string& taskId, TaskStatus status,
                                                const std::string& actorStaffId) {
    GroundTask* found = nullptr;
    auto tasks = db_.listAllTasks();
    for (auto& task : tasks) {
        if (task.getTaskId() == taskId) { found = &task; break; }
    }
    if (!found) throw NotFoundException("Ground task not found: " + taskId);

    if (!actorStaffId.empty()) {
        if (found->getAssignedStaffId().empty()) {
            throw ValidationException("Task " + taskId + " is not assigned to a ground staff member.");
        }
        if (found->getAssignedStaffId() != actorStaffId) {
            throw ValidationException("Access denied: task " + taskId + " is assigned to " +
                                      found->getAssignedStaffId() + ".");
        }
    }
    found->updateStatus(status);
    db_.updateTaskStatus(taskId, status);
}

bool GroundOperationsService::isGroundOperationComplete(const std::string& flightId) const {
    auto tasks = db_.listTasksForFlight(flightId);
    if (tasks.empty()) return false;
    for (const auto& t : tasks) if (t.getStatus() != TaskStatus::COMPLETED) return false;
    return true;
}

} // namespace services
} // namespace agoms

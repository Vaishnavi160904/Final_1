#include "services/DelayService.h"
#include "utils/Exceptions.h"

namespace agoms {
namespace services {

DelayOutcome DelayService::applyDelay(const std::string& flightId, DelayReason reason,
                                       int delayMinutes, const std::string& notes) {
    if (delayMinutes <= 0) throw ValidationException("Delay duration must be a positive number of minutes.");
    Flight flight = flightService_.getFlight(flightId);
    auto scheduleOpt = db_.findScheduleByFlightId(flightId);
    if (!scheduleOpt.has_value()) throw NotFoundException("No schedule found for flight: " + flightId);

    // A delay is legal from an operational state. If the flight is already
    // DELAYED, keep that state and append another delay record.
    const bool alreadyDelayed = flight.getStatus() == FlightStatus::DELAYED;
    if (!alreadyDelayed && !Flight::isTransitionAllowed(flight.getStatus(), FlightStatus::DELAYED, flight.getOrigin(), flight.getDestination())) {
        throw InvalidStateTransitionException(
            "Flight " + flightId + " cannot be delayed from state " + toString(flight.getStatus()) + ".");
    }

    const std::string delayId = delayIdGen_.next();
    FlightDelay delay(delayId, flightId, reason, delayMinutes, notes);
    FlightSchedule schedule = scheduleOpt.value();
    schedule.applyDelay(delayMinutes);

    db_.beginTransaction();
    try {
        db_.saveDelay(delay);
        if (!alreadyDelayed) flightService_.transitionFlightStatus(flightId, FlightStatus::DELAYED);
        db_.updateScheduleEstimates(flightId, schedule.getEstimatedArrival(), schedule.getEstimatedDeparture());
        db_.commitTransaction();
    } catch (...) {
        try { db_.rollbackTransaction(); } catch (...) {}
        throw;
    }

    DelayOutcome outcome{delay, schedule, {}};
    auto allocations = db_.listAllocationsForFlight(flightId);
    for (const auto& alloc : allocations) {
        if (alloc.getStatus() != AllocationStatus::SUCCESS) continue;
        AllocationRequest probe;
        probe.flightId = flightId;
        probe.gateId = alloc.getGateId();
        probe.vehicleId = alloc.getVehicleId();
        probe.groundStaffIds = alloc.getGroundStaffIds();
        probe.windowStart = schedule.getEstimatedArrival();
        probe.windowEnd = schedule.getEstimatedDeparture();
        ConflictResult conflict = conflictDetector_.checkConflict(probe);
        if (conflict.hasConflict()) {
            outcome.resourceWarnings.push_back(
                "Allocation " + alloc.getAllocationId() + " may need reallocation: " + conflict.getDetails());
        }
    }
    return outcome;
}

} // namespace services
} // namespace agoms

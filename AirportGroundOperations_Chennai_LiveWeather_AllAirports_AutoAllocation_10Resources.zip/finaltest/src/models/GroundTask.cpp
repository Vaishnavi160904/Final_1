#include "models/GroundTask.h"
#include "utils/Exceptions.h"
#include <utility>

namespace agoms {

GroundTask::GroundTask(std::string taskId, std::string flightId, TaskType type,
                       std::string assignedStaffId, util::DateTime startTime, util::DateTime endTime)
    : taskId_(std::move(taskId)), flightId_(std::move(flightId)), type_(type),
      assignedStaffId_(std::move(assignedStaffId)),
      status_(assignedStaffId_.empty() ? TaskStatus::PENDING : TaskStatus::ASSIGNED),
      startTime_(startTime), endTime_(endTime) {}

bool GroundTask::isStatusTransitionAllowed(TaskStatus from, TaskStatus to) {
    if (from == to) return true;
    return (from == TaskStatus::PENDING && to == TaskStatus::ASSIGNED) ||
           (from == TaskStatus::ASSIGNED && to == TaskStatus::IN_PROGRESS) ||
           (from == TaskStatus::IN_PROGRESS && (to == TaskStatus::COMPLETED || to == TaskStatus::DELAYED)) ||
           (from == TaskStatus::DELAYED && to == TaskStatus::IN_PROGRESS);
}

void GroundTask::updateStatus(TaskStatus status) {
    if (!isStatusTransitionAllowed(status_, status)) {
        throw InvalidStateTransitionException(
            "Illegal ground task state transition for " + taskId_ + ": " +
            toString(status_) + " -> " + toString(status));
    }
    status_ = status;
}

} // namespace agoms
